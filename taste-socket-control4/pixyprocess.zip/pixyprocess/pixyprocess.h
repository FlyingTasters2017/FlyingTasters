/* This file was generated automatically: DO NOT MODIFY IT ! */

/* Declaration of the functions that have to be provided by the user */

#ifndef __USER_CODE_H_pixyprocess__
#define __USER_CODE_H_pixyprocess__

#include "C_ASN1_Types.h"

#ifdef __cplusplus
extern "C" {
#endif

void pixyprocess_startup();

void pixyprocess_PI_processData(const asn1SccT_UInt32 *,
                                const asn1SccT_UInt32 *);

void pixyprocess_PI_getPosition(asn1SccMyPositionData *);

#ifdef __cplusplus
}
#endif


#endif
