/* This file was generated automatically: DO NOT MODIFY IT ! */

/* Declaration of the functions that have to be provided by the user */

#ifndef __USER_CODE_H_timer__
#define __USER_CODE_H_timer__

#ifdef __cplusplus
extern "C" {
#endif

void timer_startup();

void timer_PI_printTime();

#ifdef __cplusplus
}
#endif


#endif
