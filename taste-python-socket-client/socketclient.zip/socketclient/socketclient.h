/* This file was generated automatically: DO NOT MODIFY IT ! */

/* Declaration of the functions that have to be provided by the user */

#ifndef __USER_CODE_H_socketclient__
#define __USER_CODE_H_socketclient__

#ifdef __cplusplus
extern "C" {
#endif

void socketclient_startup();

void socketclient_PI_readStabilizerSendThrust();

#ifdef __cplusplus
}
#endif


#endif
