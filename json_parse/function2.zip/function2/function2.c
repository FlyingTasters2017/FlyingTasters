/* User code: This file will not be overwritten by TASTE. */

#include "function2.h"

void function2_startup()
{
    /* Write your initialization code here,
       but do not make any call to a required interface. */
}

void function2_PI_PI1(const asn1SccT_UInt32 *IN_x)
{
    /* Write your code here! */
}

