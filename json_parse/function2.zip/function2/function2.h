/* This file was generated automatically: DO NOT MODIFY IT ! */

/* Declaration of the functions that have to be provided by the user */

#ifndef __USER_CODE_H_function2__
#define __USER_CODE_H_function2__

#include "C_ASN1_Types.h"

#ifdef __cplusplus
extern "C" {
#endif

void function2_startup();

void function2_PI_PI1(const asn1SccT_UInt32 *);

#ifdef __cplusplus
}
#endif


#endif
