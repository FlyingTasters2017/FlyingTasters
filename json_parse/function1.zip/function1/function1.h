/* This file was generated automatically: DO NOT MODIFY IT ! */

/* Declaration of the functions that have to be provided by the user */

#ifndef __USER_CODE_H_function1__
#define __USER_CODE_H_function1__

#include "C_ASN1_Types.h"

#ifdef __cplusplus
extern "C" {
#endif

void function1_startup();

void function1_PI_getPixyData(asn1SccMyInteger *,
                              asn1SccMyInteger *);

#ifdef __cplusplus
}
#endif


#endif
