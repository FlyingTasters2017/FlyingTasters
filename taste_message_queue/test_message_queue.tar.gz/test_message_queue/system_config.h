/* This file was generated automatically - DO NOT MODIFY IT ! */

/* Configuration file used by C_ASN1_Types.h */

#define __NEED_TM_T_NATIVE
#define __NEED_TC_T_NATIVE
#define __NEED_TC_T_NATIVE
#define __NEED_TM_T_NATIVE
#define __NEED_TC_T_NATIVE
#define __NEED_TM_T_NATIVE
#define __NEED_TC_T_NATIVE
#define __NEED_TM_T_NATIVE
#define __NEED_TM_T_NATIVE
#define __NEED_TC_T_NATIVE
#define __NEED_TM_T_NATIVE
#define __NEED_TC_T_NATIVE
