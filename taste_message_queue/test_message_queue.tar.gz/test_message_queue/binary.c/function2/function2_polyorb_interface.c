#include "po_hi_gqueue.h"
/* This file was generated automatically: DO NOT MODIFY IT ! */

#include "function2_polyorb_interface.h"

#include "activity.h"
#include "types.h"
#include "po_hi_protected.h"

#include "po_hi_task.h"
#include "function2_vm_if.h"

/*----------------------------------------------------
-- Protected Provided Interface "TC_from_TASTE"
----------------------------------------------------*/
void sync_function2_TC_from_TASTE(void *tc_data, size_t tc_data_len)
{
	extern process_package__taste_protected_object function2_protected;
	__po_hi_protected_lock (function2_protected.protected_id);
	function2_TC_from_TASTE(tc_data, tc_data_len);
	__po_hi_protected_unlock (function2_protected.protected_id);
}

/* ------------------------------------------------------
--  Asynchronous Required Interface "TM_from_CF"
------------------------------------------------------ */
void vm_async_function2_TM_from_CF(void *tm_data, size_t tm_data_len)
{
	switch(__po_hi_get_task_id()) {
		case x86_partition_vt_function2_tc_from_taste_k: vm_async_vt_function2_tc_from_taste_TM_from_CF_vt(tm_data, tm_data_len); break;
		case x86_partition_vt_function2_gui_polling_function2_k: vm_async_vt_function2_gui_polling_function2_TM_from_CF_vt(tm_data, tm_data_len); break;
		default: break;
	}
}

/*----------------------------------------------------
-- Protected Provided Interface "gui_polling_function2"
----------------------------------------------------*/
void sync_function2_gui_polling_function2()
{
	extern process_package__taste_protected_object function2_protected;
	__po_hi_protected_lock (function2_protected.protected_id);
	function2_gui_polling_function2();
	__po_hi_protected_unlock (function2_protected.protected_id);
}

