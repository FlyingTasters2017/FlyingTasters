/* This file was generated automatically: DO NOT MODIFY IT ! */

#ifndef VM_IF_function2
#define VM_IF_function2

#ifdef __cplusplus
extern "C" {
#endif

#include "C_ASN1_Types.h"

/*
 * Function initialization:
 * Calls all dependent user (or GUI) startup code - including sychronous RI
*/
void init_function2();

void function2_TC_from_TASTE (void *pmy_tc_data, size_t size_my_tc_data);
extern void function2_PI_TC_from_TASTE (const asn1SccTC_T *);
void function2_gui_polling_function2 ();
extern void function2_PI_gui_polling_function2 ();
#ifdef __cplusplus
}
#endif

#endif
