/* This file was generated automatically: DO NOT MODIFY IT ! */

#ifndef _function2_GUI_HEADER_H
#define _function2_GUI_HEADER_H


#ifdef __unix__
#include <stdlib.h>
#include <stdio.h>
#endif

#include "C_ASN1_Types.h"

#include "function2_enums_def.h"


void function2_startup();

typedef struct
{
	asn1SccTC_T tc_data;
} T_TC_from_TASTE__data;

typedef struct
{
	T_function2_PI_list	message_identifier;
	T_TC_from_TASTE__data	message;
} T_TC_from_TASTE_message;


typedef struct
{
	asn1SccTM_T tm_data;
} T_TM_from_CF__data;

typedef struct
{
	T_function2_RI_list	message_identifier;
	T_TM_from_CF__data	message;
} T_TM_from_CF_message;


void function2_RI_TM_from_CF(const asn1SccTM_T *);

#define INVOKE_RI_TM_from_CF(params) function2_RI_TM_from_CF(&((T_TM_from_CF__data*)params)->tm_data);

void function2_PI_gui_polling_function2();

void function2_PI_TC_from_TASTE(const asn1SccTC_T* tc_data);



#endif
