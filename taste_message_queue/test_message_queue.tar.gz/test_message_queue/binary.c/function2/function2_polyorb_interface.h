/* This file was generated automatically: DO NOT MODIFY IT ! */

#ifndef function2_POLYORB_INTERFACE
#define function2_POLYORB_INTERFACE
#include <stddef.h>

#include "types.h"
#include "deployment.h"
#include "po_hi_transport.h"
#include "../../vt_function2_tc_from_taste/vt_function2_tc_from_taste_polyorb_interface.h"
#include "../../vt_function2_gui_polling_function2/vt_function2_gui_polling_function2_polyorb_interface.h"
/*----------------------------------------------------
-- Protected Provided Interface "TC_from_TASTE"
----------------------------------------------------*/
void sync_function2_TC_from_TASTE(void *, size_t);

/* ------------------------------------------------------
--  Asynchronous Required Interface "TM_from_CF"
------------------------------------------------------ */
void vm_async_function2_TM_from_CF(void *tm_data, size_t tm_data_len);
/*----------------------------------------------------
-- Protected Provided Interface "gui_polling_function2"
----------------------------------------------------*/
void sync_function2_gui_polling_function2();

#endif
