/* This file was generated automatically: DO NOT MODIFY IT ! */

#include <stdlib.h>
#ifdef __unix__
#include <stdio.h>
#include "PrintTypesAsASN1.h"
#include "timeInMS.h"
#endif

#include "C_ASN1_Types.h"
#include "function2_polyorb_interface.h"

void function2_RI_TM_from_CF(const asn1SccTM_T *IN_tm_data)
{
#ifdef __unix__
    static int innerMsc = -1;
    if (-1 == innerMsc)
        innerMsc = (NULL != getenv("TASTE_INNER_MSC"))?1:0;
    if (1 == innerMsc) {
        long long msc_time = getTimeInMilliseconds();

        {
            PrintASN1TM_T ("INNERDATA: TM_from_CF::TM_T::tm_data", IN_tm_data);
        }
        printf ("\nINNER: function2,function1,TM_from_CF,%lld\n", msc_time);
        fflush(stdout);
    }
#endif

    /* Buffer(s) to put the encoded input parameter(s) */
    static char IN_buf_tm_data[sizeof(asn1SccTM_T)] = {0};
    int size_IN_buf_tm_data=0;

    /* Encode each input parameter */
    size_IN_buf_tm_data = Encode_NATIVE_TM_T(IN_buf_tm_data, sizeof(asn1SccTM_T), IN_tm_data);
    if (-1 == size_IN_buf_tm_data) {
#ifdef __unix__
        printf ("** Encoding error in function2_RI_TM_from_CF!!\n");
#endif
        /* Crash the application due to message loss */
        extern void abort (void);
        abort();
    }

    /* Call to VM callback function */
    extern void vm_async_function2_TM_from_CF(void *, size_t);

    vm_async_function2_TM_from_CF(IN_buf_tm_data, size_IN_buf_tm_data);

}

