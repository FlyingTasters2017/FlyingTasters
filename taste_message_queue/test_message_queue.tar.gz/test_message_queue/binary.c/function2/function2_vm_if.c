/* This file was generated automatically: DO NOT MODIFY IT ! */

#ifdef __unix__
    #include <stdlib.h>
    #include <stdio.h>
#else
    typedef unsigned size_t;
#endif

#include "function2_vm_if.h"

#include "function2_gui_header.h"

#include "C_ASN1_Types.h"

void init_function2()
{
    static int init = 0;

    if (!init) {
        init = 1;
        function2_startup();
    }
}

void function2_TC_from_TASTE (void *pmy_tc_data, size_t size_my_tc_data)
{
    /* Decoded input variable(s): developer can use them */
    static asn1SccTC_T IN_tc_data;

#ifdef __unix__
    asn1SccTC_T_Initialize(&IN_tc_data);
#endif

    /* Decode each input parameter */
    if (0 != Decode_NATIVE_TC_T (&IN_tc_data, pmy_tc_data, size_my_tc_data)) {
        #ifdef __unix__
            printf("\nError Decoding TC_T\n");
        #endif
        return;
    }

    /* Call to User-defined function */
    function2_PI_TC_from_TASTE (&IN_tc_data);

}
void function2_gui_polling_function2 ()
{
    /* Call to User-defined function */
    function2_PI_gui_polling_function2 ();

}
