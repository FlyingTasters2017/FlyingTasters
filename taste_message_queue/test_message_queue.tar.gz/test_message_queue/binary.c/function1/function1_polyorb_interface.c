#include "po_hi_gqueue.h"
/* This file was generated automatically: DO NOT MODIFY IT ! */

#include "function1_polyorb_interface.h"

#include "activity.h"
#include "types.h"
#include "po_hi_task.h"
#include "function1_vm_if.h"

/* ------------------------------------------------------
-- Asynchronous Provided Interface "TM_from_CF"
------------------------------------------------------ */
void po_hi_c_function1_tm_from_cf(__po_hi_task_id e, dataview__tm_t_buffer_impl buf)
{
	function1_TM_from_CF(buf.buffer, buf.length);
}

/*----------------------------------------------------
-- Unprotected Provided Interface "TC_from_TASTE"
----------------------------------------------------*/
void sync_function1_TC_from_TASTE(void *tc_data, size_t tc_data_len)
{
	function1_TC_from_TASTE(tc_data, tc_data_len);
}

/* ------------------------------------------------------
--  Asynchronous Required Interface "TC_from_TASTE"
------------------------------------------------------ */
void vm_async_function1_TC_from_TASTE(void *tc_data, size_t tc_data_len)
{
	__po_hi_request_t request;

	__po_hi_copy_array(&(request.vars.function1_global_outport_tc_from_taste.function1_global_outport_tc_from_taste.buffer), tc_data, tc_data_len);
	request.vars.function1_global_outport_tc_from_taste.function1_global_outport_tc_from_taste.length = tc_data_len;
	request.port = function1_global_outport_tc_from_taste;
	__po_hi_gqueue_store_out(x86_partition_function1_k, function1_local_outport_tc_from_taste, &request);
	__po_hi_send_output(x86_partition_function1_k, function1_global_outport_tc_from_taste);
}

/* ------------------------------------------------------
--  Asynchronous Required Interface "TM_from_CF"
------------------------------------------------------ */
void vm_async_function1_TM_from_CF(void *tm_data, size_t tm_data_len)
{
	__po_hi_request_t request;

	__po_hi_copy_array(&(request.vars.function1_global_outport_tm_from_cf.function1_global_outport_tm_from_cf.buffer), tm_data, tm_data_len);
	request.vars.function1_global_outport_tm_from_cf.function1_global_outport_tm_from_cf.length = tm_data_len;
	request.port = function1_global_outport_tm_from_cf;
	__po_hi_gqueue_store_out(x86_partition_function1_k, function1_local_outport_tm_from_cf, &request);
	__po_hi_send_output(x86_partition_function1_k, function1_global_outport_tm_from_cf);
}

/* ------------------------------------------------------
--  Synchronous Required Interface "check_queue"
------------------------------------------------------ */
void vm_function1_check_queue(void *res, size_t *res_len)
{
	sync_x86_partition_taste_api_function1_has_pending_msg(res, res_len);
}

