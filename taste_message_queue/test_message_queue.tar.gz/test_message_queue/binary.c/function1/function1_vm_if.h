/* This file was generated automatically: DO NOT MODIFY IT ! */

#ifndef VM_IF_function1
#define VM_IF_function1

#ifdef __cplusplus
extern "C" {
#endif

#include "C_ASN1_Types.h"

/*
 * Function initialization:
 * Calls all dependent user (or GUI) startup code - including sychronous RI
*/
void init_function1();

void function1_TM_from_CF (void *pmy_tm_data, size_t size_my_tm_data);
extern void function1_PI_TM_from_CF (const asn1SccTM_T *);
void function1_TC_from_TASTE (void *pmy_tc_data, size_t size_my_tc_data);
extern void function1_PI_TC_from_TASTE (const asn1SccTC_T *);
#ifdef __cplusplus
}
#endif

#endif
