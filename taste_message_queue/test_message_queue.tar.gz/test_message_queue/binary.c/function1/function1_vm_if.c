/* This file was generated automatically: DO NOT MODIFY IT ! */

#ifdef __unix__
    #include <stdlib.h>
    #include <stdio.h>
#else
    typedef unsigned size_t;
#endif

#include "function1_vm_if.h"

#include "function1.h"

#include "C_ASN1_Types.h"

void init_function1()
{
    static int init = 0;

    if (!init) {
        init = 1;
        function1_startup();
        extern void init_x86_partition_taste_api();
        init_x86_partition_taste_api();
    }
}

void function1_TM_from_CF (void *pmy_tm_data, size_t size_my_tm_data)
{
    /* Decoded input variable(s): developer can use them */
    static asn1SccTM_T IN_tm_data;

#ifdef __unix__
    asn1SccTM_T_Initialize(&IN_tm_data);
#endif

    /* Decode each input parameter */
    if (0 != Decode_NATIVE_TM_T (&IN_tm_data, pmy_tm_data, size_my_tm_data)) {
        #ifdef __unix__
            printf("\nError Decoding TM_T\n");
        #endif
        return;
    }

    /* Call to User-defined function */
    function1_PI_TM_from_CF (&IN_tm_data);

}
void function1_TC_from_TASTE (void *pmy_tc_data, size_t size_my_tc_data)
{
    /* Decoded input variable(s): developer can use them */
    asn1SccTC_T IN_tc_data;

#ifdef __unix__
    asn1SccTC_T_Initialize(&IN_tc_data);
#endif

    /* Decode each input parameter */
    if (0 != Decode_NATIVE_TC_T (&IN_tc_data, pmy_tc_data, size_my_tc_data)) {
        #ifdef __unix__
            printf("\nError Decoding TC_T\n");
        #endif
        return;
    }

    /* Call to User-defined function */
    function1_PI_TC_from_TASTE (&IN_tc_data);

}
