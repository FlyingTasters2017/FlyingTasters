/* This file was generated automatically: DO NOT MODIFY IT ! */

#ifndef function1_POLYORB_INTERFACE
#define function1_POLYORB_INTERFACE
#include <stddef.h>

#include "types.h"
#include "deployment.h"
#include "po_hi_transport.h"
#include "../../x86_partition_taste_api/x86_partition_taste_api_polyorb_interface.h"
#include "../../vt_function2_tc_from_taste/vt_function2_tc_from_taste_polyorb_interface.h"
#include "../../vt_function2_gui_polling_function2/vt_function2_gui_polling_function2_polyorb_interface.h"
#include "../../vt_mainsupervisor_pulse/vt_mainsupervisor_pulse_polyorb_interface.h"
#include "../../vt_mainsupervisor_takeoff/vt_mainsupervisor_takeoff_polyorb_interface.h"
#include "../../vt_mainsupervisor_tm_from_cf/vt_mainsupervisor_tm_from_cf_polyorb_interface.h"
/*----------------------------------------------------
-- Asynchronous Provided Interface "TM_from_CF"
----------------------------------------------------*/
void po_hi_c_function1_tm_from_cf(__po_hi_task_id, dataview__tm_t_buffer_impl);

/*----------------------------------------------------
-- Unprotected Provided Interface "TC_from_TASTE"
----------------------------------------------------*/
void sync_function1_TC_from_TASTE(void *, size_t);

/* ------------------------------------------------------
--  Asynchronous Required Interface "TC_from_TASTE"
------------------------------------------------------ */
void vm_async_function1_TC_from_TASTE(void *tc_data, size_t tc_data_len);
/* ------------------------------------------------------
--  Asynchronous Required Interface "TM_from_CF"
------------------------------------------------------ */
void vm_async_function1_TM_from_CF(void *tm_data, size_t tm_data_len);
/* ------------------------------------------------------
--  Synchronous Required Interface "check_queue"
------------------------------------------------------ */
void vm_function1_check_queue(void *, size_t *);
#endif
