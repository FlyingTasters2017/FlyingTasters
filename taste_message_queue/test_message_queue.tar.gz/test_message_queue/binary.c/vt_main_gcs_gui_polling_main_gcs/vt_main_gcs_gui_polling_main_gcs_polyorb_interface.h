/* This file was generated automatically: DO NOT MODIFY IT ! */

#ifndef vt_main_gcs_gui_polling_main_gcs_POLYORB_INTERFACE
#define vt_main_gcs_gui_polling_main_gcs_POLYORB_INTERFACE
#include <stddef.h>

#include "types.h"
#include "deployment.h"
#include "po_hi_transport.h"
#include "../../main_gcs/main_gcs_polyorb_interface.h"
/*----------------------------------------------------
-- Asynchronous Provided Interface "artificial_gui_polling_main_gcs"
----------------------------------------------------*/
void po_hi_c_vt_main_gcs_gui_polling_main_gcs_artificial_gui_polling_main_gcs(__po_hi_task_id);

/* ------------------------------------------------------
--  Synchronous Required Interface "gui_polling_main_gcs"
------------------------------------------------------ */
void vm_vt_main_gcs_gui_polling_main_gcs_gui_polling_main_gcs();
/* ------------------------------------------------------
--  Asynchronous Required Interface "takeoff_vt"
------------------------------------------------------ */
void vm_async_vt_main_gcs_gui_polling_main_gcs_takeoff_vt(void *tc_data, size_t tc_data_len);
#endif
