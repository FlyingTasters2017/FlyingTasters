/* This file was generated automatically: DO NOT MODIFY IT ! */

#ifndef main_gcs_POLYORB_INTERFACE
#define main_gcs_POLYORB_INTERFACE
#include <stddef.h>

#include "types.h"
#include "deployment.h"
#include "po_hi_transport.h"
#include "../../vt_main_gcs_displaydata/vt_main_gcs_displaydata_polyorb_interface.h"
#include "../../vt_main_gcs_gui_polling_main_gcs/vt_main_gcs_gui_polling_main_gcs_polyorb_interface.h"
/*----------------------------------------------------
-- Protected Provided Interface "displayData"
----------------------------------------------------*/
void sync_main_gcs_displayData(void *, size_t);

/* ------------------------------------------------------
--  Asynchronous Required Interface "takeoff"
------------------------------------------------------ */
void vm_async_main_gcs_takeoff(void *tc_data, size_t tc_data_len);
/*----------------------------------------------------
-- Protected Provided Interface "gui_polling_main_gcs"
----------------------------------------------------*/
void sync_main_gcs_gui_polling_main_gcs();

#endif
