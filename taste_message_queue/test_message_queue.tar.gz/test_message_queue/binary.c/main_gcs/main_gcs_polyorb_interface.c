#include "po_hi_gqueue.h"
/* This file was generated automatically: DO NOT MODIFY IT ! */

#include "main_gcs_polyorb_interface.h"

#include "activity.h"
#include "types.h"
#include "po_hi_protected.h"

#include "po_hi_task.h"
#include "main_gcs_vm_if.h"

/*----------------------------------------------------
-- Protected Provided Interface "displayData"
----------------------------------------------------*/
void sync_main_gcs_displayData(void *tm_data, size_t tm_data_len)
{
	extern process_package__taste_protected_object main_gcs_protected;
	__po_hi_protected_lock (main_gcs_protected.protected_id);
	main_gcs_displayData(tm_data, tm_data_len);
	__po_hi_protected_unlock (main_gcs_protected.protected_id);
}

/* ------------------------------------------------------
--  Asynchronous Required Interface "takeoff"
------------------------------------------------------ */
void vm_async_main_gcs_takeoff(void *tc_data, size_t tc_data_len)
{
	switch(__po_hi_get_task_id()) {
		case x86_partition_vt_main_gcs_displaydata_k: vm_async_vt_main_gcs_displaydata_takeoff_vt(tc_data, tc_data_len); break;
		case x86_partition_vt_main_gcs_gui_polling_main_gcs_k: vm_async_vt_main_gcs_gui_polling_main_gcs_takeoff_vt(tc_data, tc_data_len); break;
		default: break;
	}
}

/*----------------------------------------------------
-- Protected Provided Interface "gui_polling_main_gcs"
----------------------------------------------------*/
void sync_main_gcs_gui_polling_main_gcs()
{
	extern process_package__taste_protected_object main_gcs_protected;
	__po_hi_protected_lock (main_gcs_protected.protected_id);
	main_gcs_gui_polling_main_gcs();
	__po_hi_protected_unlock (main_gcs_protected.protected_id);
}

