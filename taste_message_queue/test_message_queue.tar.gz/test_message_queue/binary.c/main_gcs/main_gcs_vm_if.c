/* This file was generated automatically: DO NOT MODIFY IT ! */

#ifdef __unix__
    #include <stdlib.h>
    #include <stdio.h>
#else
    typedef unsigned size_t;
#endif

#include "main_gcs_vm_if.h"

#include "main_gcs_gui_header.h"

#include "C_ASN1_Types.h"

void init_main_gcs()
{
    static int init = 0;

    if (!init) {
        init = 1;
        main_gcs_startup();
    }
}

void main_gcs_displayData (void *pmy_tm_data, size_t size_my_tm_data)
{
    /* Decoded input variable(s): developer can use them */
    static asn1SccTM_T IN_tm_data;

#ifdef __unix__
    asn1SccTM_T_Initialize(&IN_tm_data);
#endif

    /* Decode each input parameter */
    if (0 != Decode_NATIVE_TM_T (&IN_tm_data, pmy_tm_data, size_my_tm_data)) {
        #ifdef __unix__
            printf("\nError Decoding TM_T\n");
        #endif
        return;
    }

    /* Call to User-defined function */
    main_gcs_PI_displayData (&IN_tm_data);

}
void main_gcs_gui_polling_main_gcs ()
{
    /* Call to User-defined function */
    main_gcs_PI_gui_polling_main_gcs ();

}
