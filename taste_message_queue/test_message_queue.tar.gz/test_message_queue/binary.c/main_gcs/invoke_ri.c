/* This file was generated automatically: DO NOT MODIFY IT ! */

#include <stdlib.h>
#ifdef __unix__
#include <stdio.h>
#include "PrintTypesAsASN1.h"
#include "timeInMS.h"
#endif

#include "C_ASN1_Types.h"
#include "main_gcs_polyorb_interface.h"

void main_gcs_RI_takeoff(const asn1SccTC_T *IN_tc_data)
{
#ifdef __unix__
    static int innerMsc = -1;
    if (-1 == innerMsc)
        innerMsc = (NULL != getenv("TASTE_INNER_MSC"))?1:0;
    if (1 == innerMsc) {
        long long msc_time = getTimeInMilliseconds();

        {
            PrintASN1TC_T ("INNERDATA: takeoff::TC_T::tc_data", IN_tc_data);
        }
        printf ("\nINNER: main_gcs,mainsupervisor,takeoff,%lld\n", msc_time);
        fflush(stdout);
    }
#endif

    /* Buffer(s) to put the encoded input parameter(s) */
    static char IN_buf_tc_data[sizeof(asn1SccTC_T)] = {0};
    int size_IN_buf_tc_data=0;

    /* Encode each input parameter */
    size_IN_buf_tc_data = Encode_NATIVE_TC_T(IN_buf_tc_data, sizeof(asn1SccTC_T), IN_tc_data);
    if (-1 == size_IN_buf_tc_data) {
#ifdef __unix__
        printf ("** Encoding error in main_gcs_RI_takeoff!!\n");
#endif
        /* Crash the application due to message loss */
        extern void abort (void);
        abort();
    }

    /* Call to VM callback function */
    extern void vm_async_main_gcs_takeoff(void *, size_t);

    vm_async_main_gcs_takeoff(IN_buf_tc_data, size_IN_buf_tc_data);

}

