/* This file was generated automatically: DO NOT MODIFY IT ! */

#ifndef _main_gcs_GUI_HEADER_H
#define _main_gcs_GUI_HEADER_H


#ifdef __unix__
#include <stdlib.h>
#include <stdio.h>
#endif

#include "C_ASN1_Types.h"

#include "main_gcs_enums_def.h"


void main_gcs_startup();

typedef struct
{
	asn1SccTM_T tm_data;
} T_displayData__data;

typedef struct
{
	T_main_gcs_PI_list	message_identifier;
	T_displayData__data	message;
} T_displayData_message;


typedef struct
{
	asn1SccTC_T tc_data;
} T_takeoff__data;

typedef struct
{
	T_main_gcs_RI_list	message_identifier;
	T_takeoff__data	message;
} T_takeoff_message;


void main_gcs_RI_takeoff(const asn1SccTC_T *);

#define INVOKE_RI_takeoff(params) main_gcs_RI_takeoff(&((T_takeoff__data*)params)->tc_data);

void main_gcs_PI_gui_polling_main_gcs();

void main_gcs_PI_displayData(const asn1SccTM_T* tm_data);



#endif
