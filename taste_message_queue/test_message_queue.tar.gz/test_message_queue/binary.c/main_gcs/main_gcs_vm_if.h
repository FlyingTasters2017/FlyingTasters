/* This file was generated automatically: DO NOT MODIFY IT ! */

#ifndef VM_IF_main_gcs
#define VM_IF_main_gcs

#ifdef __cplusplus
extern "C" {
#endif

#include "C_ASN1_Types.h"

/*
 * Function initialization:
 * Calls all dependent user (or GUI) startup code - including sychronous RI
*/
void init_main_gcs();

void main_gcs_displayData (void *pmy_tm_data, size_t size_my_tm_data);
extern void main_gcs_PI_displayData (const asn1SccTM_T *);
void main_gcs_gui_polling_main_gcs ();
extern void main_gcs_PI_gui_polling_main_gcs ();
#ifdef __cplusplus
}
#endif

#endif
