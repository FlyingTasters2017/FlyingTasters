#ifdef __unix__
#include <stdio.h>
#endif
#include "PrintTypes.h"

#ifdef __linux__
#include <pthread.h>

static pthread_mutex_t g_printing_mutex = PTHREAD_MUTEX_INITIALIZER;

#endif

void PrintMyInteger(const char *paramName, const asn1SccMyInteger *pData)
{
#ifdef __linux__
    pthread_mutex_lock(&g_printing_mutex);
#endif
#ifdef __unix__
    #if WORD_SIZE==8
    printf("%s %lld\n", paramName, (*pData));
    #else
    printf("%s %d\n", paramName, (*pData));
    #endif
#endif
#ifdef __linux__
    pthread_mutex_unlock(&g_printing_mutex);
#endif
}

void PrintACCELERATION(const char *paramName, const asn1SccACCELERATION *pData)
{
#ifdef __linux__
    pthread_mutex_lock(&g_printing_mutex);
#endif
#ifdef __unix__
    printf("%s %f\n", paramName, (*pData));
#endif
#ifdef __linux__
    pthread_mutex_unlock(&g_printing_mutex);
#endif
}

void PrintRATE(const char *paramName, const asn1SccRATE *pData)
{
#ifdef __linux__
    pthread_mutex_lock(&g_printing_mutex);
#endif
#ifdef __unix__
    printf("%s %f\n", paramName, (*pData));
#endif
#ifdef __linux__
    pthread_mutex_unlock(&g_printing_mutex);
#endif
}

void PrintMySeq(const char *paramName, const asn1SccMySeq *pData)
{
#ifdef __linux__
    pthread_mutex_lock(&g_printing_mutex);
#endif
#ifdef __unix__
    #if WORD_SIZE==8
    printf("%s::input_data %lld\n", paramName, (*pData).input_data);
    #else
    printf("%s::input_data %d\n", paramName, (*pData).input_data);
    #endif
    #if WORD_SIZE==8
    printf("%s::output_data %lld\n", paramName, (*pData).output_data);
    #else
    printf("%s::output_data %d\n", paramName, (*pData).output_data);
    #endif
    printf("%s::validity %d\n", paramName, (int)(*pData).validity);
#endif
#ifdef __linux__
    pthread_mutex_unlock(&g_printing_mutex);
#endif
}

void PrintMySeqOf(const char *paramName, const asn1SccMySeqOf *pData)
{
#ifdef __linux__
    pthread_mutex_lock(&g_printing_mutex);
#endif
#ifdef __unix__
    {
        int i1;
        for(i1=0; i1<2; i1++) {
            printf("%s::Elem %d\n", paramName, (int)(*pData).arr[i1]);
        }
    }
#endif
#ifdef __linux__
    pthread_mutex_unlock(&g_printing_mutex);
#endif
}

void PrintMyReal(const char *paramName, const asn1SccMyReal *pData)
{
#ifdef __linux__
    pthread_mutex_lock(&g_printing_mutex);
#endif
#ifdef __unix__
    printf("%s %f\n", paramName, (*pData));
#endif
#ifdef __linux__
    pthread_mutex_unlock(&g_printing_mutex);
#endif
}

void PrintTC_T(const char *paramName, const asn1SccTC_T *pData)
{
#ifdef __linux__
    pthread_mutex_lock(&g_printing_mutex);
#endif
#ifdef __unix__
    printf("%s::roll %f\n", paramName, (*pData).roll);
    printf("%s::pitch %f\n", paramName, (*pData).pitch);
    printf("%s::yaw %f\n", paramName, (*pData).yaw);
    #if WORD_SIZE==8
    printf("%s::thrust %lld\n", paramName, (*pData).thrust);
    #else
    printf("%s::thrust %d\n", paramName, (*pData).thrust);
    #endif
#endif
#ifdef __linux__
    pthread_mutex_unlock(&g_printing_mutex);
#endif
}

void PrintTM_T(const char *paramName, const asn1SccTM_T *pData)
{
#ifdef __linux__
    pthread_mutex_lock(&g_printing_mutex);
#endif
#ifdef __unix__
    printf("%s::gyro::x %f\n", paramName, (*pData).gyro.x);
    printf("%s::gyro::y %f\n", paramName, (*pData).gyro.y);
    printf("%s::gyro::z %f\n", paramName, (*pData).gyro.z);
    printf("%s::acc::x %f\n", paramName, (*pData).acc.x);
    printf("%s::acc::y %f\n", paramName, (*pData).acc.y);
    printf("%s::acc::z %f\n", paramName, (*pData).acc.z);
    #if WORD_SIZE==8
    printf("%s::z %lld\n", paramName, (*pData).z);
    #else
    printf("%s::z %d\n", paramName, (*pData).z);
    #endif
#endif
#ifdef __linux__
    pthread_mutex_unlock(&g_printing_mutex);
#endif
}

void PrintACC_SEQ(const char *paramName, const asn1SccACC_SEQ *pData)
{
#ifdef __linux__
    pthread_mutex_lock(&g_printing_mutex);
#endif
#ifdef __unix__
    printf("%s::x %f\n", paramName, (*pData).x);
    printf("%s::y %f\n", paramName, (*pData).y);
    printf("%s::z %f\n", paramName, (*pData).z);
#endif
#ifdef __linux__
    pthread_mutex_unlock(&g_printing_mutex);
#endif
}

void PrintT_UInt32(const char *paramName, const asn1SccT_UInt32 *pData)
{
#ifdef __linux__
    pthread_mutex_lock(&g_printing_mutex);
#endif
#ifdef __unix__
    #if WORD_SIZE==8
    printf("%s %lld\n", paramName, (*pData));
    #else
    printf("%s %d\n", paramName, (*pData));
    #endif
#endif
#ifdef __linux__
    pthread_mutex_unlock(&g_printing_mutex);
#endif
}

void PrintMyBool(const char *paramName, const asn1SccMyBool *pData)
{
#ifdef __linux__
    pthread_mutex_lock(&g_printing_mutex);
#endif
#ifdef __unix__
    printf("%s %d\n", paramName, (int)(*pData));
#endif
#ifdef __linux__
    pthread_mutex_unlock(&g_printing_mutex);
#endif
}

void PrintT_UInt8(const char *paramName, const asn1SccT_UInt8 *pData)
{
#ifdef __linux__
    pthread_mutex_lock(&g_printing_mutex);
#endif
#ifdef __unix__
    #if WORD_SIZE==8
    printf("%s %lld\n", paramName, (*pData));
    #else
    printf("%s %d\n", paramName, (*pData));
    #endif
#endif
#ifdef __linux__
    pthread_mutex_unlock(&g_printing_mutex);
#endif
}

void PrintMyOctStr(const char *paramName, const asn1SccMyOctStr *pData)
{
#ifdef __linux__
    pthread_mutex_lock(&g_printing_mutex);
#endif
#ifdef __unix__
    {
        int i;
        printf("%s ", paramName);
        for(i=0; i<3; i++)
            printf("%c", (*pData).arr[i]);
        printf("\n");
    }

#endif
#ifdef __linux__
    pthread_mutex_unlock(&g_printing_mutex);
#endif
}

void PrintANGLE(const char *paramName, const asn1SccANGLE *pData)
{
#ifdef __linux__
    pthread_mutex_lock(&g_printing_mutex);
#endif
#ifdef __unix__
    printf("%s %f\n", paramName, (*pData));
#endif
#ifdef __linux__
    pthread_mutex_unlock(&g_printing_mutex);
#endif
}

void PrintT_Int8(const char *paramName, const asn1SccT_Int8 *pData)
{
#ifdef __linux__
    pthread_mutex_lock(&g_printing_mutex);
#endif
#ifdef __unix__
    #if WORD_SIZE==8
    printf("%s %lld\n", paramName, (*pData));
    #else
    printf("%s %d\n", paramName, (*pData));
    #endif
#endif
#ifdef __linux__
    pthread_mutex_unlock(&g_printing_mutex);
#endif
}

void PrintGYROSCOPE(const char *paramName, const asn1SccGYROSCOPE *pData)
{
#ifdef __linux__
    pthread_mutex_lock(&g_printing_mutex);
#endif
#ifdef __unix__
    printf("%s %f\n", paramName, (*pData));
#endif
#ifdef __linux__
    pthread_mutex_unlock(&g_printing_mutex);
#endif
}

void PrintHEIGHT(const char *paramName, const asn1SccHEIGHT *pData)
{
#ifdef __linux__
    pthread_mutex_lock(&g_printing_mutex);
#endif
#ifdef __unix__
    #if WORD_SIZE==8
    printf("%s %lld\n", paramName, (*pData));
    #else
    printf("%s %d\n", paramName, (*pData));
    #endif
#endif
#ifdef __linux__
    pthread_mutex_unlock(&g_printing_mutex);
#endif
}

void PrintGYRO_SEQ(const char *paramName, const asn1SccGYRO_SEQ *pData)
{
#ifdef __linux__
    pthread_mutex_lock(&g_printing_mutex);
#endif
#ifdef __unix__
    printf("%s::x %f\n", paramName, (*pData).x);
    printf("%s::y %f\n", paramName, (*pData).y);
    printf("%s::z %f\n", paramName, (*pData).z);
#endif
#ifdef __linux__
    pthread_mutex_unlock(&g_printing_mutex);
#endif
}

void PrintT_Boolean(const char *paramName, const asn1SccT_Boolean *pData)
{
#ifdef __linux__
    pthread_mutex_lock(&g_printing_mutex);
#endif
#ifdef __unix__
    printf("%s %d\n", paramName, (int)(*pData));
#endif
#ifdef __linux__
    pthread_mutex_unlock(&g_printing_mutex);
#endif
}

void PrintT_Int32(const char *paramName, const asn1SccT_Int32 *pData)
{
#ifdef __linux__
    pthread_mutex_lock(&g_printing_mutex);
#endif
#ifdef __unix__
    #if WORD_SIZE==8
    printf("%s %lld\n", paramName, (*pData));
    #else
    printf("%s %d\n", paramName, (*pData));
    #endif
#endif
#ifdef __linux__
    pthread_mutex_unlock(&g_printing_mutex);
#endif
}

void PrintMyEnum(const char *paramName, const asn1SccMyEnum *pData)
{
#ifdef __linux__
    pthread_mutex_lock(&g_printing_mutex);
#endif
#ifdef __unix__
    printf("%s %d\n", paramName, (int)(*pData));
#endif
#ifdef __linux__
    pthread_mutex_unlock(&g_printing_mutex);
#endif
}

void PrintMyChoice(const char *paramName, const asn1SccMyChoice *pData)
{
#ifdef __linux__
    pthread_mutex_lock(&g_printing_mutex);
#endif
#ifdef __unix__
    if ((*pData).kind == a_PRESENT) {
        printf("%s::a %d\n", paramName, (int)(*pData).u.a);
    }
    else if ((*pData).kind == b_PRESENT) {
        #if WORD_SIZE==8
        printf("%s::b::input_data %lld\n", paramName, (*pData).u.b.input_data);
        #else
        printf("%s::b::input_data %d\n", paramName, (*pData).u.b.input_data);
        #endif
        #if WORD_SIZE==8
        printf("%s::b::output_data %lld\n", paramName, (*pData).u.b.output_data);
        #else
        printf("%s::b::output_data %d\n", paramName, (*pData).u.b.output_data);
        #endif
        printf("%s::b::validity %d\n", paramName, (int)(*pData).u.b.validity);
    }
#endif
#ifdef __linux__
    pthread_mutex_unlock(&g_printing_mutex);
#endif
}

void PrintT_UInt16(const char *paramName, const asn1SccT_UInt16 *pData)
{
#ifdef __linux__
    pthread_mutex_lock(&g_printing_mutex);
#endif
#ifdef __unix__
    #if WORD_SIZE==8
    printf("%s %lld\n", paramName, (*pData));
    #else
    printf("%s %d\n", paramName, (*pData));
    #endif
#endif
#ifdef __linux__
    pthread_mutex_unlock(&g_printing_mutex);
#endif
}

