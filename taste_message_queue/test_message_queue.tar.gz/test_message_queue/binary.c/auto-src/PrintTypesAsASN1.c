#ifdef __unix__
#include <stdio.h>
#endif

#include "PrintTypesAsASN1.h"

#ifdef __linux__
#include <pthread.h>

static pthread_mutex_t g_printing_mutex = PTHREAD_MUTEX_INITIALIZER;

#endif

void PrintASN1TM_T(const char *paramName, const asn1SccTM_T *pData)
{
#ifdef __linux__
    pthread_mutex_lock(&g_printing_mutex);
#endif
#ifdef __unix__
    //printf("%s TM-T ::= ", paramName);
    printf("%s ", paramName);
    printf("{");
    printf("gyro ");
    printf("{");
    printf("x ");
    printf("%f", (*pData).gyro.x);
    printf(", ");
    printf("y ");
    printf("%f", (*pData).gyro.y);
    printf(", ");
    printf("z ");
    printf("%f", (*pData).gyro.z);
    printf("}");
    printf(", ");
    printf("acc ");
    printf("{");
    printf("x ");
    printf("%f", (*pData).acc.x);
    printf(", ");
    printf("y ");
    printf("%f", (*pData).acc.y);
    printf(", ");
    printf("z ");
    printf("%f", (*pData).acc.z);
    printf("}");
    printf(", ");
    printf("z ");
    #if WORD_SIZE==8
    printf("%lld", (*pData).z);
    #else
    printf("%d", (*pData).z);
    #endif
    printf("}");
#endif
#ifdef __linux__
    pthread_mutex_unlock(&g_printing_mutex);
#endif
}

void PrintASN1TC_T(const char *paramName, const asn1SccTC_T *pData)
{
#ifdef __linux__
    pthread_mutex_lock(&g_printing_mutex);
#endif
#ifdef __unix__
    //printf("%s TC-T ::= ", paramName);
    printf("%s ", paramName);
    printf("{");
    printf("roll ");
    printf("%f", (*pData).roll);
    printf(", ");
    printf("pitch ");
    printf("%f", (*pData).pitch);
    printf(", ");
    printf("yaw ");
    printf("%f", (*pData).yaw);
    printf(", ");
    printf("thrust ");
    #if WORD_SIZE==8
    printf("%lld", (*pData).thrust);
    #else
    printf("%d", (*pData).thrust);
    #endif
    printf("}");
#endif
#ifdef __linux__
    pthread_mutex_unlock(&g_printing_mutex);
#endif
}

void PrintASN1ANGLE(const char *paramName, const asn1SccANGLE *pData)
{
#ifdef __linux__
    pthread_mutex_lock(&g_printing_mutex);
#endif
#ifdef __unix__
    //printf("%s ANGLE ::= ", paramName);
    printf("%s ", paramName);
    printf("%f", (*pData));
#endif
#ifdef __linux__
    pthread_mutex_unlock(&g_printing_mutex);
#endif
}

void PrintASN1RATE(const char *paramName, const asn1SccRATE *pData)
{
#ifdef __linux__
    pthread_mutex_lock(&g_printing_mutex);
#endif
#ifdef __unix__
    //printf("%s RATE ::= ", paramName);
    printf("%s ", paramName);
    printf("%f", (*pData));
#endif
#ifdef __linux__
    pthread_mutex_unlock(&g_printing_mutex);
#endif
}

void PrintASN1MySeqOf(const char *paramName, const asn1SccMySeqOf *pData)
{
#ifdef __linux__
    pthread_mutex_lock(&g_printing_mutex);
#endif
#ifdef __unix__
    //printf("%s MySeqOf ::= ", paramName);
    printf("%s ", paramName);
    {
        int i1;
        printf("{");
        for(i1=0; i1<2; i1++) {
            if (i1) 
                printf(",");
            switch((*pData).arr[i1]) {
            case 0:
                printf("hello");
                break;
            case 1:
                printf("world");
                break;
            case 2:
                printf("howareyou");
                break;
            default:
                printf("Invalid value in ENUMERATED ((*pData).arr[i1])");
            }
        }
        printf("}");
    }
#endif
#ifdef __linux__
    pthread_mutex_unlock(&g_printing_mutex);
#endif
}

void PrintASN1HEIGHT(const char *paramName, const asn1SccHEIGHT *pData)
{
#ifdef __linux__
    pthread_mutex_lock(&g_printing_mutex);
#endif
#ifdef __unix__
    //printf("%s HEIGHT ::= ", paramName);
    printf("%s ", paramName);
    #if WORD_SIZE==8
    printf("%lld", (*pData));
    #else
    printf("%d", (*pData));
    #endif
#endif
#ifdef __linux__
    pthread_mutex_unlock(&g_printing_mutex);
#endif
}

void PrintASN1MyEnum(const char *paramName, const asn1SccMyEnum *pData)
{
#ifdef __linux__
    pthread_mutex_lock(&g_printing_mutex);
#endif
#ifdef __unix__
    //printf("%s MyEnum ::= ", paramName);
    printf("%s ", paramName);
    switch((*pData)) {
    case 0:
        printf("hello");
        break;
    case 1:
        printf("world");
        break;
    case 2:
        printf("howareyou");
        break;
    default:
        printf("Invalid value in ENUMERATED ((*pData))");
    }
#endif
#ifdef __linux__
    pthread_mutex_unlock(&g_printing_mutex);
#endif
}

void PrintASN1MyReal(const char *paramName, const asn1SccMyReal *pData)
{
#ifdef __linux__
    pthread_mutex_lock(&g_printing_mutex);
#endif
#ifdef __unix__
    //printf("%s MyReal ::= ", paramName);
    printf("%s ", paramName);
    printf("%f", (*pData));
#endif
#ifdef __linux__
    pthread_mutex_unlock(&g_printing_mutex);
#endif
}

void PrintASN1T_UInt32(const char *paramName, const asn1SccT_UInt32 *pData)
{
#ifdef __linux__
    pthread_mutex_lock(&g_printing_mutex);
#endif
#ifdef __unix__
    //printf("%s T-UInt32 ::= ", paramName);
    printf("%s ", paramName);
    #if WORD_SIZE==8
    printf("%lld", (*pData));
    #else
    printf("%d", (*pData));
    #endif
#endif
#ifdef __linux__
    pthread_mutex_unlock(&g_printing_mutex);
#endif
}

void PrintASN1GYROSCOPE(const char *paramName, const asn1SccGYROSCOPE *pData)
{
#ifdef __linux__
    pthread_mutex_lock(&g_printing_mutex);
#endif
#ifdef __unix__
    //printf("%s GYROSCOPE ::= ", paramName);
    printf("%s ", paramName);
    printf("%f", (*pData));
#endif
#ifdef __linux__
    pthread_mutex_unlock(&g_printing_mutex);
#endif
}

void PrintASN1MyBool(const char *paramName, const asn1SccMyBool *pData)
{
#ifdef __linux__
    pthread_mutex_lock(&g_printing_mutex);
#endif
#ifdef __unix__
    //printf("%s MyBool ::= ", paramName);
    printf("%s ", paramName);
    printf("%s", (int)(*pData)?"TRUE":"FALSE");
#endif
#ifdef __linux__
    pthread_mutex_unlock(&g_printing_mutex);
#endif
}

void PrintASN1T_Int8(const char *paramName, const asn1SccT_Int8 *pData)
{
#ifdef __linux__
    pthread_mutex_lock(&g_printing_mutex);
#endif
#ifdef __unix__
    //printf("%s T-Int8 ::= ", paramName);
    printf("%s ", paramName);
    #if WORD_SIZE==8
    printf("%lld", (*pData));
    #else
    printf("%d", (*pData));
    #endif
#endif
#ifdef __linux__
    pthread_mutex_unlock(&g_printing_mutex);
#endif
}

void PrintASN1MyChoice(const char *paramName, const asn1SccMyChoice *pData)
{
#ifdef __linux__
    pthread_mutex_lock(&g_printing_mutex);
#endif
#ifdef __unix__
    //printf("%s MyChoice ::= ", paramName);
    printf("%s ", paramName);
    if ((*pData).kind == a_PRESENT) {
        printf("a:");
        printf("%s", (int)(*pData).u.a?"TRUE":"FALSE");
    }
    else if ((*pData).kind == b_PRESENT) {
        printf("b:");
        printf("{");
        printf("input-data ");
        #if WORD_SIZE==8
        printf("%lld", (*pData).u.b.input_data);
        #else
        printf("%d", (*pData).u.b.input_data);
        #endif
        printf(", ");
        printf("output-data ");
        #if WORD_SIZE==8
        printf("%lld", (*pData).u.b.output_data);
        #else
        printf("%d", (*pData).u.b.output_data);
        #endif
        printf(", ");
        printf("validity ");
        switch((*pData).u.b.validity) {
        case 0:
            printf("valid");
            break;
        case 1:
            printf("invalid");
            break;
        default:
            printf("Invalid value in ENUMERATED ((*pData).u.b.validity)");
        }
        printf("}");
    }
#endif
#ifdef __linux__
    pthread_mutex_unlock(&g_printing_mutex);
#endif
}

void PrintASN1MySeq(const char *paramName, const asn1SccMySeq *pData)
{
#ifdef __linux__
    pthread_mutex_lock(&g_printing_mutex);
#endif
#ifdef __unix__
    //printf("%s MySeq ::= ", paramName);
    printf("%s ", paramName);
    printf("{");
    printf("input-data ");
    #if WORD_SIZE==8
    printf("%lld", (*pData).input_data);
    #else
    printf("%d", (*pData).input_data);
    #endif
    printf(", ");
    printf("output-data ");
    #if WORD_SIZE==8
    printf("%lld", (*pData).output_data);
    #else
    printf("%d", (*pData).output_data);
    #endif
    printf(", ");
    printf("validity ");
    switch((*pData).validity) {
    case 0:
        printf("valid");
        break;
    case 1:
        printf("invalid");
        break;
    default:
        printf("Invalid value in ENUMERATED ((*pData).validity)");
    }
    printf("}");
#endif
#ifdef __linux__
    pthread_mutex_unlock(&g_printing_mutex);
#endif
}

void PrintASN1ACCELERATION(const char *paramName, const asn1SccACCELERATION *pData)
{
#ifdef __linux__
    pthread_mutex_lock(&g_printing_mutex);
#endif
#ifdef __unix__
    //printf("%s ACCELERATION ::= ", paramName);
    printf("%s ", paramName);
    printf("%f", (*pData));
#endif
#ifdef __linux__
    pthread_mutex_unlock(&g_printing_mutex);
#endif
}

void PrintASN1MyInteger(const char *paramName, const asn1SccMyInteger *pData)
{
#ifdef __linux__
    pthread_mutex_lock(&g_printing_mutex);
#endif
#ifdef __unix__
    //printf("%s MyInteger ::= ", paramName);
    printf("%s ", paramName);
    #if WORD_SIZE==8
    printf("%lld", (*pData));
    #else
    printf("%d", (*pData));
    #endif
#endif
#ifdef __linux__
    pthread_mutex_unlock(&g_printing_mutex);
#endif
}

void PrintASN1T_Boolean(const char *paramName, const asn1SccT_Boolean *pData)
{
#ifdef __linux__
    pthread_mutex_lock(&g_printing_mutex);
#endif
#ifdef __unix__
    //printf("%s T-Boolean ::= ", paramName);
    printf("%s ", paramName);
    printf("%s", (int)(*pData)?"TRUE":"FALSE");
#endif
#ifdef __linux__
    pthread_mutex_unlock(&g_printing_mutex);
#endif
}

void PrintASN1ACC_SEQ(const char *paramName, const asn1SccACC_SEQ *pData)
{
#ifdef __linux__
    pthread_mutex_lock(&g_printing_mutex);
#endif
#ifdef __unix__
    //printf("%s ACC-SEQ ::= ", paramName);
    printf("%s ", paramName);
    printf("{");
    printf("x ");
    printf("%f", (*pData).x);
    printf(", ");
    printf("y ");
    printf("%f", (*pData).y);
    printf(", ");
    printf("z ");
    printf("%f", (*pData).z);
    printf("}");
#endif
#ifdef __linux__
    pthread_mutex_unlock(&g_printing_mutex);
#endif
}

void PrintASN1T_UInt16(const char *paramName, const asn1SccT_UInt16 *pData)
{
#ifdef __linux__
    pthread_mutex_lock(&g_printing_mutex);
#endif
#ifdef __unix__
    //printf("%s T-UInt16 ::= ", paramName);
    printf("%s ", paramName);
    #if WORD_SIZE==8
    printf("%lld", (*pData));
    #else
    printf("%d", (*pData));
    #endif
#endif
#ifdef __linux__
    pthread_mutex_unlock(&g_printing_mutex);
#endif
}

void PrintASN1MyOctStr(const char *paramName, const asn1SccMyOctStr *pData)
{
#ifdef __linux__
    pthread_mutex_lock(&g_printing_mutex);
#endif
#ifdef __unix__
    //printf("%s MyOctStr ::= ", paramName);
    printf("%s ", paramName);
    {
        int i;
        printf("'");
        for(i=0; i<3; i++)
            printf("%02x", (*pData).arr[i]);
        printf("'H");
    }

#endif
#ifdef __linux__
    pthread_mutex_unlock(&g_printing_mutex);
#endif
}

void PrintASN1T_Int32(const char *paramName, const asn1SccT_Int32 *pData)
{
#ifdef __linux__
    pthread_mutex_lock(&g_printing_mutex);
#endif
#ifdef __unix__
    //printf("%s T-Int32 ::= ", paramName);
    printf("%s ", paramName);
    #if WORD_SIZE==8
    printf("%lld", (*pData));
    #else
    printf("%d", (*pData));
    #endif
#endif
#ifdef __linux__
    pthread_mutex_unlock(&g_printing_mutex);
#endif
}

void PrintASN1GYRO_SEQ(const char *paramName, const asn1SccGYRO_SEQ *pData)
{
#ifdef __linux__
    pthread_mutex_lock(&g_printing_mutex);
#endif
#ifdef __unix__
    //printf("%s GYRO-SEQ ::= ", paramName);
    printf("%s ", paramName);
    printf("{");
    printf("x ");
    printf("%f", (*pData).x);
    printf(", ");
    printf("y ");
    printf("%f", (*pData).y);
    printf(", ");
    printf("z ");
    printf("%f", (*pData).z);
    printf("}");
#endif
#ifdef __linux__
    pthread_mutex_unlock(&g_printing_mutex);
#endif
}

void PrintASN1T_UInt8(const char *paramName, const asn1SccT_UInt8 *pData)
{
#ifdef __linux__
    pthread_mutex_lock(&g_printing_mutex);
#endif
#ifdef __unix__
    //printf("%s T-UInt8 ::= ", paramName);
    printf("%s ", paramName);
    #if WORD_SIZE==8
    printf("%lld", (*pData));
    #else
    printf("%d", (*pData));
    #endif
#endif
#ifdef __linux__
    pthread_mutex_unlock(&g_printing_mutex);
#endif
}

