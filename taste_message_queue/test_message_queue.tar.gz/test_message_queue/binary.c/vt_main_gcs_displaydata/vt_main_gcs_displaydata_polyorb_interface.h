/* This file was generated automatically: DO NOT MODIFY IT ! */

#ifndef vt_main_gcs_displaydata_POLYORB_INTERFACE
#define vt_main_gcs_displaydata_POLYORB_INTERFACE
#include <stddef.h>

#include "types.h"
#include "deployment.h"
#include "po_hi_transport.h"
#include "../../main_gcs/main_gcs_polyorb_interface.h"
/*----------------------------------------------------
-- Asynchronous Provided Interface "artificial_displayData"
----------------------------------------------------*/
void po_hi_c_vt_main_gcs_displaydata_artificial_displaydata(__po_hi_task_id, dataview__tm_t_buffer_impl);

/* ------------------------------------------------------
--  Synchronous Required Interface "displayData"
------------------------------------------------------ */
void vm_vt_main_gcs_displaydata_displayData(void *tm_data, size_t tm_data_len);
/* ------------------------------------------------------
--  Asynchronous Required Interface "takeoff_vt"
------------------------------------------------------ */
void vm_async_vt_main_gcs_displaydata_takeoff_vt(void *tc_data, size_t tc_data_len);
#endif
