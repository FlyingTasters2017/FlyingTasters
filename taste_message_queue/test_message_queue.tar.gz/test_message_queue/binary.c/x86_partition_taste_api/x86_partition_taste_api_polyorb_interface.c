/* This file was generated automatically: DO NOT MODIFY IT ! */

#include "x86_partition_taste_api_polyorb_interface.h"

#include "activity.h"
#include "types.h"
#include "po_hi_task.h"
#include "x86_partition_taste_api_vm_if.h"

/*----------------------------------------------------
-- Unprotected Provided Interface "function1_has_pending_msg"
----------------------------------------------------*/
void sync_x86_partition_taste_api_function1_has_pending_msg(void *res, size_t *res_len)
{
	x86_partition_taste_api_function1_has_pending_msg(res, res_len);
}

/*----------------------------------------------------
-- Unprotected Provided Interface "mainsupervisor_has_pending_msg"
----------------------------------------------------*/
void sync_x86_partition_taste_api_mainsupervisor_has_pending_msg(void *res, size_t *res_len)
{
	x86_partition_taste_api_mainsupervisor_has_pending_msg(res, res_len);
}

