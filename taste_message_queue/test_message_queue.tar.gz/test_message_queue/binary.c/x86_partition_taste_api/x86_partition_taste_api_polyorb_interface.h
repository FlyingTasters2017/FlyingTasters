/* This file was generated automatically: DO NOT MODIFY IT ! */

#ifndef x86_partition_taste_api_POLYORB_INTERFACE
#define x86_partition_taste_api_POLYORB_INTERFACE
#include <stddef.h>

#include "deployment.h"
#include "po_hi_transport.h"
#include "../../function1/function1_polyorb_interface.h"
#include "../../vt_mainsupervisor_pulse/vt_mainsupervisor_pulse_polyorb_interface.h"
#include "../../vt_mainsupervisor_takeoff/vt_mainsupervisor_takeoff_polyorb_interface.h"
#include "../../vt_mainsupervisor_tm_from_cf/vt_mainsupervisor_tm_from_cf_polyorb_interface.h"
/*----------------------------------------------------
-- Unprotected Provided Interface "function1_has_pending_msg"
----------------------------------------------------*/
void sync_x86_partition_taste_api_function1_has_pending_msg(void *, size_t *);

/*----------------------------------------------------
-- Unprotected Provided Interface "mainsupervisor_has_pending_msg"
----------------------------------------------------*/
void sync_x86_partition_taste_api_mainsupervisor_has_pending_msg(void *, size_t *);

#endif
