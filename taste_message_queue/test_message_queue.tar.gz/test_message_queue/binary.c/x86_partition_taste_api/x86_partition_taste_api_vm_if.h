/* This file was generated automatically: DO NOT MODIFY IT ! */

#ifndef VM_IF_x86_partition_taste_api
#define VM_IF_x86_partition_taste_api

#ifdef __cplusplus
extern "C" {
#endif

#include "C_ASN1_Types.h"

/*
 * Function initialization:
 * Calls all dependent user (or GUI) startup code - including sychronous RI
*/
void init_x86_partition_taste_api();

void x86_partition_taste_api_function1_has_pending_msg (void *pmy_res, size_t *psize_my_res);
extern void x86_partition_taste_api_PI_function1_has_pending_msg (asn1SccT_Boolean *);
void x86_partition_taste_api_mainsupervisor_has_pending_msg (void *pmy_res, size_t *psize_my_res);
extern void x86_partition_taste_api_PI_mainsupervisor_has_pending_msg (asn1SccT_Boolean *);
#ifdef __cplusplus
}
#endif

#endif
