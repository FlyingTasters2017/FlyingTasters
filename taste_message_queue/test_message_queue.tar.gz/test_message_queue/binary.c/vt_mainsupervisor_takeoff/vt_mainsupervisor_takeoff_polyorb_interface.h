/* This file was generated automatically: DO NOT MODIFY IT ! */

#ifndef vt_mainsupervisor_takeoff_POLYORB_INTERFACE
#define vt_mainsupervisor_takeoff_POLYORB_INTERFACE
#include <stddef.h>

#include "types.h"
#include "deployment.h"
#include "po_hi_transport.h"
#include "../../mainsupervisor/mainsupervisor_polyorb_interface.h"
#include "../../function1/function1_polyorb_interface.h"
#include "../../x86_partition_taste_api/x86_partition_taste_api_polyorb_interface.h"
/*----------------------------------------------------
-- Asynchronous Provided Interface "artificial_takeoff"
----------------------------------------------------*/
void po_hi_c_vt_mainsupervisor_takeoff_artificial_takeoff(__po_hi_task_id, dataview__tc_t_buffer_impl);

/* ------------------------------------------------------
--  Synchronous Required Interface "takeoff"
------------------------------------------------------ */
void vm_vt_mainsupervisor_takeoff_takeoff(void *tc_data, size_t tc_data_len);
/* ------------------------------------------------------
--  Asynchronous Required Interface "displayData_vt"
------------------------------------------------------ */
void vm_async_vt_mainsupervisor_takeoff_displayData_vt(void *tm_data, size_t tm_data_len);
/* ------------------------------------------------------
--  Synchronous Required Interface "TC_from_TASTE_vt"
------------------------------------------------------ */
void vm_vt_mainsupervisor_takeoff_TC_from_TASTE_vt(void *tc_data, size_t tc_data_len);
/* ------------------------------------------------------
--  Synchronous Required Interface "check_queue_vt"
------------------------------------------------------ */
void vm_vt_mainsupervisor_takeoff_check_queue_vt(void *, size_t *);
#endif
