/* This file was generated automatically: DO NOT MODIFY IT ! */

#ifndef vt_function2_gui_polling_function2_POLYORB_INTERFACE
#define vt_function2_gui_polling_function2_POLYORB_INTERFACE
#include <stddef.h>

#include "types.h"
#include "deployment.h"
#include "po_hi_transport.h"
#include "../../function2/function2_polyorb_interface.h"
/*----------------------------------------------------
-- Asynchronous Provided Interface "artificial_gui_polling_function2"
----------------------------------------------------*/
void po_hi_c_vt_function2_gui_polling_function2_artificial_gui_polling_function2(__po_hi_task_id);

/* ------------------------------------------------------
--  Synchronous Required Interface "gui_polling_function2"
------------------------------------------------------ */
void vm_vt_function2_gui_polling_function2_gui_polling_function2();
/* ------------------------------------------------------
--  Asynchronous Required Interface "TM_from_CF_vt"
------------------------------------------------------ */
void vm_async_vt_function2_gui_polling_function2_TM_from_CF_vt(void *tm_data, size_t tm_data_len);
#endif
