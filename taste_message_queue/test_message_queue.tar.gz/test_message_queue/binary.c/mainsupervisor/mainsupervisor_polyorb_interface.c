#include "po_hi_gqueue.h"
/* This file was generated automatically: DO NOT MODIFY IT ! */

#include "mainsupervisor_polyorb_interface.h"

#include "activity.h"
#include "types.h"
#include "po_hi_protected.h"

#include "po_hi_task.h"
#include "mainsupervisor_vm_if.h"

/*----------------------------------------------------
-- Protected Provided Interface "pulse"
----------------------------------------------------*/
void sync_mainsupervisor_pulse()
{
	extern process_package__taste_protected_object mainsupervisor_protected;
	__po_hi_protected_lock (mainsupervisor_protected.protected_id);
	mainsupervisor_pulse();
	__po_hi_protected_unlock (mainsupervisor_protected.protected_id);
}

/*----------------------------------------------------
-- Protected Provided Interface "takeoff"
----------------------------------------------------*/
void sync_mainsupervisor_takeoff(void *tc_data, size_t tc_data_len)
{
	extern process_package__taste_protected_object mainsupervisor_protected;
	__po_hi_protected_lock (mainsupervisor_protected.protected_id);
	mainsupervisor_takeoff(tc_data, tc_data_len);
	__po_hi_protected_unlock (mainsupervisor_protected.protected_id);
}

/*----------------------------------------------------
-- Protected Provided Interface "TM_from_CF"
----------------------------------------------------*/
void sync_mainsupervisor_TM_from_CF(void *tm_data, size_t tm_data_len)
{
	extern process_package__taste_protected_object mainsupervisor_protected;
	__po_hi_protected_lock (mainsupervisor_protected.protected_id);
	mainsupervisor_TM_from_CF(tm_data, tm_data_len);
	__po_hi_protected_unlock (mainsupervisor_protected.protected_id);
}

/* ------------------------------------------------------
--  Asynchronous Required Interface "displayData"
------------------------------------------------------ */
void vm_async_mainsupervisor_displayData(void *tm_data, size_t tm_data_len)
{
	switch(__po_hi_get_task_id()) {
		case x86_partition_vt_mainsupervisor_pulse_k: vm_async_vt_mainsupervisor_pulse_displayData_vt(tm_data, tm_data_len); break;
		case x86_partition_vt_mainsupervisor_takeoff_k: vm_async_vt_mainsupervisor_takeoff_displayData_vt(tm_data, tm_data_len); break;
		case x86_partition_vt_mainsupervisor_tm_from_cf_k: vm_async_vt_mainsupervisor_tm_from_cf_displayData_vt(tm_data, tm_data_len); break;
		default: break;
	}
}

/* ------------------------------------------------------
--  Synchronous Required Interface "TC_from_TASTE"
------------------------------------------------------ */
void vm_mainsupervisor_TC_from_TASTE(void *tc_data, size_t tc_data_len)
{
	sync_function1_TC_from_TASTE(tc_data, tc_data_len);
}

/* ------------------------------------------------------
--  Synchronous Required Interface "check_queue"
------------------------------------------------------ */
void vm_mainsupervisor_check_queue(void *res, size_t *res_len)
{
	sync_x86_partition_taste_api_mainsupervisor_has_pending_msg(res, res_len);
}

