/* This file was generated automatically: DO NOT MODIFY IT ! */

/* Declaration of the functions that have to be provided by the user */

#ifndef __USER_CODE_H_mainsupervisor__
#define __USER_CODE_H_mainsupervisor__

#include "C_ASN1_Types.h"

#ifdef __cplusplus
extern "C" {
#endif

void mainsupervisor_startup();

#ifdef __cplusplus
}
#endif


#endif
