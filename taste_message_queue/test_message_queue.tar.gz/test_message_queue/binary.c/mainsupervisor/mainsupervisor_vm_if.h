/* This file was generated automatically: DO NOT MODIFY IT ! */

#ifndef VM_IF_mainsupervisor
#define VM_IF_mainsupervisor

#ifdef __cplusplus
extern "C" {
#endif

#include "C_ASN1_Types.h"

/*
 * Function initialization:
 * Calls all dependent user (or GUI) startup code - including sychronous RI
*/
void init_mainsupervisor();

extern void adainit();
void mainsupervisor_pulse ();
extern void mainsupervisor_PI_pulse ();
void mainsupervisor_takeoff (void *pmy_tc_data, size_t size_my_tc_data);
extern void mainsupervisor_PI_takeoff (const asn1SccTC_T *);
void mainsupervisor_TM_from_CF (void *pmy_tm_data, size_t size_my_tm_data);
extern void mainsupervisor_PI_TM_from_CF (const asn1SccTM_T *);
#ifdef __cplusplus
}
#endif

#endif
