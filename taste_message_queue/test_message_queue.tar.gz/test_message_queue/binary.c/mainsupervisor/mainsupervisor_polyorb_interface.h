/* This file was generated automatically: DO NOT MODIFY IT ! */

#ifndef mainsupervisor_POLYORB_INTERFACE
#define mainsupervisor_POLYORB_INTERFACE
#include <stddef.h>

#include "types.h"
#include "deployment.h"
#include "po_hi_transport.h"
#include "../../function1/function1_polyorb_interface.h"
#include "../../x86_partition_taste_api/x86_partition_taste_api_polyorb_interface.h"
#include "../../vt_mainsupervisor_pulse/vt_mainsupervisor_pulse_polyorb_interface.h"
#include "../../vt_mainsupervisor_takeoff/vt_mainsupervisor_takeoff_polyorb_interface.h"
#include "../../vt_mainsupervisor_tm_from_cf/vt_mainsupervisor_tm_from_cf_polyorb_interface.h"
/*----------------------------------------------------
-- Protected Provided Interface "pulse"
----------------------------------------------------*/
void sync_mainsupervisor_pulse();

/*----------------------------------------------------
-- Protected Provided Interface "takeoff"
----------------------------------------------------*/
void sync_mainsupervisor_takeoff(void *, size_t);

/*----------------------------------------------------
-- Protected Provided Interface "TM_from_CF"
----------------------------------------------------*/
void sync_mainsupervisor_TM_from_CF(void *, size_t);

/* ------------------------------------------------------
--  Asynchronous Required Interface "displayData"
------------------------------------------------------ */
void vm_async_mainsupervisor_displayData(void *tm_data, size_t tm_data_len);
/* ------------------------------------------------------
--  Synchronous Required Interface "TC_from_TASTE"
------------------------------------------------------ */
void vm_mainsupervisor_TC_from_TASTE(void *tc_data, size_t tc_data_len);
/* ------------------------------------------------------
--  Synchronous Required Interface "check_queue"
------------------------------------------------------ */
void vm_mainsupervisor_check_queue(void *, size_t *);
#endif
