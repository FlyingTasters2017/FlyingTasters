#!/usr/bin/python

import DV

FVname = "main_gcs"

tc = {}
tm = {}
errCodes = {}

tm["displayData"] = {'nodeTypename': 'TM-T', 'type': 'SEQUENCE', 'id': 'displayData', "children":[{'nodeTypename': '', 'type': 'SEQUENCE', 'id': 'gyro', "children":[{'nodeTypename': '', 'type': 'REAL', 'id': 'x', 'minR': -100000, 'maxR': 100000},
{'nodeTypename': '', 'type': 'REAL', 'id': 'y', 'minR': -100000, 'maxR': 100000},
{'nodeTypename': '', 'type': 'REAL', 'id': 'z', 'minR': -100000, 'maxR': 100000}]},
{'nodeTypename': '', 'type': 'SEQUENCE', 'id': 'acc', "children":[{'nodeTypename': '', 'type': 'REAL', 'id': 'x', 'minR': -16, 'maxR': 16},
{'nodeTypename': '', 'type': 'REAL', 'id': 'y', 'minR': -16, 'maxR': 16},
{'nodeTypename': '', 'type': 'REAL', 'id': 'z', 'minR': -16, 'maxR': 16}]},
{'nodeTypename': '', 'type': 'INTEGER', 'id': 'z', 'minR': 0, 'maxR': 8191}]}
tc["takeoff"] = {'nodeTypename': 'TC-T', 'type': 'SEQUENCE', 'id': 'takeoff', "children":[{'nodeTypename': '', 'type': 'REAL', 'id': 'roll', 'minR': -360, 'maxR': 360},
{'nodeTypename': '', 'type': 'REAL', 'id': 'pitch', 'minR': -360, 'maxR': 360},
{'nodeTypename': '', 'type': 'REAL', 'id': 'yaw', 'minR': -100000, 'maxR': 100000},
{'nodeTypename': '', 'type': 'INTEGER', 'id': 'thrust', 'minR': 0, 'maxR': 65535}]}
