/* This file was generated automatically: DO NOT MODIFY IT ! */

#ifndef _main_gcs_ENUM_DEF_H
#define _main_gcs_ENUM_DEF_H


typedef enum {
  i_takeoff,
} T_main_gcs_RI_list;

typedef enum {
  i_displayData,
} T_main_gcs_PI_list;



#endif
