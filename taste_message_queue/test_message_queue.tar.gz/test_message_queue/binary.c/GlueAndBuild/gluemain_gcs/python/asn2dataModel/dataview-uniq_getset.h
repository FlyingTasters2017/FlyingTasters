#ifndef __GETSET_H__
#define __GETSET_H__

#include "dataview-uniq.h"

size_t GetStreamCurrentLength(BitStream *pBitStrm);
byte *GetBitstreamBuffer(BitStream *pBitStrm);
byte GetBufferByte(byte *p, size_t off);
void SetBufferByte(byte *p, size_t off, byte b);
void ResetStream(BitStream *pStrm);
BitStream *CreateStream(size_t bufferSize);
void DestroyStream(BitStream *pBitStrm);


/* BOOLEAN */
flag T_Boolean__Get(T_Boolean* root);

/* BOOLEAN */
void T_Boolean__Set(T_Boolean* root, flag value);

/* BOOLEAN */
flag MyBool__Get(MyBool* root);

/* BOOLEAN */
void MyBool__Set(MyBool* root, flag value);

/* Field gyro selector */
GYRO_SEQ* TM_T__gyro_Get(TM_T* root);

/* REAL */
double TM_T__gyro_x_Get(TM_T* root);

/* REAL */
void TM_T__gyro_x_Set(TM_T* root, double value);

/* REAL */
double TM_T__gyro_y_Get(TM_T* root);

/* REAL */
void TM_T__gyro_y_Set(TM_T* root, double value);

/* REAL */
double TM_T__gyro_z_Get(TM_T* root);

/* REAL */
void TM_T__gyro_z_Set(TM_T* root, double value);

/* Field acc selector */
ACC_SEQ* TM_T__acc_Get(TM_T* root);

/* REAL */
double TM_T__acc_x_Get(TM_T* root);

/* REAL */
void TM_T__acc_x_Set(TM_T* root, double value);

/* REAL */
double TM_T__acc_y_Get(TM_T* root);

/* REAL */
void TM_T__acc_y_Set(TM_T* root, double value);

/* REAL */
double TM_T__acc_z_Get(TM_T* root);

/* REAL */
void TM_T__acc_z_Set(TM_T* root, double value);

/* INTEGER */
asn1SccSint TM_T__z_Get(TM_T* root);

/* INTEGER */
void TM_T__z_Set(TM_T* root, asn1SccSint value);

/* SEQUENCEOF/SETOF */
long MySeqOf__GetLength(MySeqOf* root);

/* SEQUENCEOF/SETOF */
void MySeqOf__SetLength(MySeqOf* root, long value);

/* ENUMERATED */
int MySeqOf__iDx_Get(MySeqOf* root, int iDx);

/* ENUMERATED */
void MySeqOf__iDx_Set(MySeqOf* root, int iDx, int value);

/* INTEGER */
asn1SccSint MyInteger__Get(MyInteger* root);

/* INTEGER */
void MyInteger__Set(MyInteger* root, asn1SccSint value);

/* INTEGER */
asn1SccSint T_UInt32__Get(T_UInt32* root);

/* INTEGER */
void T_UInt32__Set(T_UInt32* root, asn1SccSint value);

/* REAL */
double ACC_SEQ__x_Get(ACC_SEQ* root);

/* REAL */
void ACC_SEQ__x_Set(ACC_SEQ* root, double value);

/* REAL */
double ACC_SEQ__y_Get(ACC_SEQ* root);

/* REAL */
void ACC_SEQ__y_Set(ACC_SEQ* root, double value);

/* REAL */
double ACC_SEQ__z_Get(ACC_SEQ* root);

/* REAL */
void ACC_SEQ__z_Set(ACC_SEQ* root, double value);

/* REAL */
double ACCELERATION__Get(ACCELERATION* root);

/* REAL */
void ACCELERATION__Set(ACCELERATION* root, double value);

/* REAL */
double GYROSCOPE__Get(GYROSCOPE* root);

/* REAL */
void GYROSCOPE__Set(GYROSCOPE* root, double value);

/* REAL */
double TC_T__roll_Get(TC_T* root);

/* REAL */
void TC_T__roll_Set(TC_T* root, double value);

/* REAL */
double TC_T__pitch_Get(TC_T* root);

/* REAL */
void TC_T__pitch_Set(TC_T* root, double value);

/* REAL */
double TC_T__yaw_Get(TC_T* root);

/* REAL */
void TC_T__yaw_Set(TC_T* root, double value);

/* INTEGER */
asn1SccSint TC_T__thrust_Get(TC_T* root);

/* INTEGER */
void TC_T__thrust_Set(TC_T* root, asn1SccSint value);

/* INTEGER */
asn1SccSint HEIGHT__Get(HEIGHT* root);

/* INTEGER */
void HEIGHT__Set(HEIGHT* root, asn1SccSint value);

/* REAL */
double MyReal__Get(MyReal* root);

/* REAL */
void MyReal__Set(MyReal* root, double value);

/* INTEGER */
asn1SccSint MySeq__input_data_Get(MySeq* root);

/* INTEGER */
void MySeq__input_data_Set(MySeq* root, asn1SccSint value);

/* INTEGER */
asn1SccSint MySeq__output_data_Get(MySeq* root);

/* INTEGER */
void MySeq__output_data_Set(MySeq* root, asn1SccSint value);

/* ENUMERATED */
int MySeq__validity_Get(MySeq* root);

/* ENUMERATED */
void MySeq__validity_Set(MySeq* root, int value);

/* INTEGER */
asn1SccSint T_Int8__Get(T_Int8* root);

/* INTEGER */
void T_Int8__Set(T_Int8* root, asn1SccSint value);

/* INTEGER */
asn1SccSint T_UInt8__Get(T_UInt8* root);

/* INTEGER */
void T_UInt8__Set(T_UInt8* root, asn1SccSint value);

/* REAL */
double RATE__Get(RATE* root);

/* REAL */
void RATE__Set(RATE* root, double value);

/* CHOICE selector */
int MyChoice__kind_Get(MyChoice* root);

/* CHOICE selector */
void MyChoice__kind_Set(MyChoice* root, int value);

/* BOOLEAN */
flag MyChoice__a_Get(MyChoice* root);

/* BOOLEAN */
void MyChoice__a_Set(MyChoice* root, flag value);

/* Field b selector */
MySeq* MyChoice__b_Get(MyChoice* root);

/* INTEGER */
asn1SccSint MyChoice__b_input_data_Get(MyChoice* root);

/* INTEGER */
void MyChoice__b_input_data_Set(MyChoice* root, asn1SccSint value);

/* INTEGER */
asn1SccSint MyChoice__b_output_data_Get(MyChoice* root);

/* INTEGER */
void MyChoice__b_output_data_Set(MyChoice* root, asn1SccSint value);

/* ENUMERATED */
int MyChoice__b_validity_Get(MyChoice* root);

/* ENUMERATED */
void MyChoice__b_validity_Set(MyChoice* root, int value);

/* REAL */
double ANGLE__Get(ANGLE* root);

/* REAL */
void ANGLE__Set(ANGLE* root, double value);

/* OCTETSTRING */
long MyOctStr__GetLength(MyOctStr* root);

/* OCTETSTRING */
void MyOctStr__SetLength(MyOctStr* root, long value);

/* OCTETSTRING_bytes */
byte MyOctStr__iDx_Get(MyOctStr* root, int iDx);

/* OCTETSTRING_bytes */
void MyOctStr__iDx_Set(MyOctStr* root, int iDx, byte value);

/* INTEGER */
asn1SccSint T_UInt16__Get(T_UInt16* root);

/* INTEGER */
void T_UInt16__Set(T_UInt16* root, asn1SccSint value);

/* REAL */
double GYRO_SEQ__x_Get(GYRO_SEQ* root);

/* REAL */
void GYRO_SEQ__x_Set(GYRO_SEQ* root, double value);

/* REAL */
double GYRO_SEQ__y_Get(GYRO_SEQ* root);

/* REAL */
void GYRO_SEQ__y_Set(GYRO_SEQ* root, double value);

/* REAL */
double GYRO_SEQ__z_Get(GYRO_SEQ* root);

/* REAL */
void GYRO_SEQ__z_Set(GYRO_SEQ* root, double value);

/* INTEGER */
asn1SccSint T_Int32__Get(T_Int32* root);

/* INTEGER */
void T_Int32__Set(T_Int32* root, asn1SccSint value);

/* ENUMERATED */
int MyEnum__Get(MyEnum* root);

/* ENUMERATED */
void MyEnum__Set(MyEnum* root, int value);

/* Helper functions for NATIVE encodings */

void SetDataFor_T_Boolean(void *dest, void *src);
byte* MovePtrBySizeOf_T_Boolean(byte *pData);
byte* CreateInstanceOf_T_Boolean(void);
void DestroyInstanceOf_T_Boolean(byte *pData);

void SetDataFor_MyBool(void *dest, void *src);
byte* MovePtrBySizeOf_MyBool(byte *pData);
byte* CreateInstanceOf_MyBool(void);
void DestroyInstanceOf_MyBool(byte *pData);

void SetDataFor_TM_T(void *dest, void *src);
byte* MovePtrBySizeOf_TM_T(byte *pData);
byte* CreateInstanceOf_TM_T(void);
void DestroyInstanceOf_TM_T(byte *pData);

void SetDataFor_MySeqOf(void *dest, void *src);
byte* MovePtrBySizeOf_MySeqOf(byte *pData);
byte* CreateInstanceOf_MySeqOf(void);
void DestroyInstanceOf_MySeqOf(byte *pData);

void SetDataFor_MyInteger(void *dest, void *src);
byte* MovePtrBySizeOf_MyInteger(byte *pData);
byte* CreateInstanceOf_MyInteger(void);
void DestroyInstanceOf_MyInteger(byte *pData);

void SetDataFor_T_UInt32(void *dest, void *src);
byte* MovePtrBySizeOf_T_UInt32(byte *pData);
byte* CreateInstanceOf_T_UInt32(void);
void DestroyInstanceOf_T_UInt32(byte *pData);

void SetDataFor_ACC_SEQ(void *dest, void *src);
byte* MovePtrBySizeOf_ACC_SEQ(byte *pData);
byte* CreateInstanceOf_ACC_SEQ(void);
void DestroyInstanceOf_ACC_SEQ(byte *pData);

void SetDataFor_ACCELERATION(void *dest, void *src);
byte* MovePtrBySizeOf_ACCELERATION(byte *pData);
byte* CreateInstanceOf_ACCELERATION(void);
void DestroyInstanceOf_ACCELERATION(byte *pData);

void SetDataFor_GYROSCOPE(void *dest, void *src);
byte* MovePtrBySizeOf_GYROSCOPE(byte *pData);
byte* CreateInstanceOf_GYROSCOPE(void);
void DestroyInstanceOf_GYROSCOPE(byte *pData);

void SetDataFor_TC_T(void *dest, void *src);
byte* MovePtrBySizeOf_TC_T(byte *pData);
byte* CreateInstanceOf_TC_T(void);
void DestroyInstanceOf_TC_T(byte *pData);

void SetDataFor_HEIGHT(void *dest, void *src);
byte* MovePtrBySizeOf_HEIGHT(byte *pData);
byte* CreateInstanceOf_HEIGHT(void);
void DestroyInstanceOf_HEIGHT(byte *pData);

void SetDataFor_MyReal(void *dest, void *src);
byte* MovePtrBySizeOf_MyReal(byte *pData);
byte* CreateInstanceOf_MyReal(void);
void DestroyInstanceOf_MyReal(byte *pData);

void SetDataFor_MySeq(void *dest, void *src);
byte* MovePtrBySizeOf_MySeq(byte *pData);
byte* CreateInstanceOf_MySeq(void);
void DestroyInstanceOf_MySeq(byte *pData);

void SetDataFor_T_Int8(void *dest, void *src);
byte* MovePtrBySizeOf_T_Int8(byte *pData);
byte* CreateInstanceOf_T_Int8(void);
void DestroyInstanceOf_T_Int8(byte *pData);

void SetDataFor_T_UInt8(void *dest, void *src);
byte* MovePtrBySizeOf_T_UInt8(byte *pData);
byte* CreateInstanceOf_T_UInt8(void);
void DestroyInstanceOf_T_UInt8(byte *pData);

void SetDataFor_RATE(void *dest, void *src);
byte* MovePtrBySizeOf_RATE(byte *pData);
byte* CreateInstanceOf_RATE(void);
void DestroyInstanceOf_RATE(byte *pData);

void SetDataFor_MyChoice(void *dest, void *src);
byte* MovePtrBySizeOf_MyChoice(byte *pData);
byte* CreateInstanceOf_MyChoice(void);
void DestroyInstanceOf_MyChoice(byte *pData);

void SetDataFor_ANGLE(void *dest, void *src);
byte* MovePtrBySizeOf_ANGLE(byte *pData);
byte* CreateInstanceOf_ANGLE(void);
void DestroyInstanceOf_ANGLE(byte *pData);

void SetDataFor_MyOctStr(void *dest, void *src);
byte* MovePtrBySizeOf_MyOctStr(byte *pData);
byte* CreateInstanceOf_MyOctStr(void);
void DestroyInstanceOf_MyOctStr(byte *pData);

void SetDataFor_T_UInt16(void *dest, void *src);
byte* MovePtrBySizeOf_T_UInt16(byte *pData);
byte* CreateInstanceOf_T_UInt16(void);
void DestroyInstanceOf_T_UInt16(byte *pData);

void SetDataFor_GYRO_SEQ(void *dest, void *src);
byte* MovePtrBySizeOf_GYRO_SEQ(byte *pData);
byte* CreateInstanceOf_GYRO_SEQ(void);
void DestroyInstanceOf_GYRO_SEQ(byte *pData);

void SetDataFor_T_Int32(void *dest, void *src);
byte* MovePtrBySizeOf_T_Int32(byte *pData);
byte* CreateInstanceOf_T_Int32(void);
void DestroyInstanceOf_T_Int32(byte *pData);

void SetDataFor_MyEnum(void *dest, void *src);
byte* MovePtrBySizeOf_MyEnum(byte *pData);
byte* CreateInstanceOf_MyEnum(void);
void DestroyInstanceOf_MyEnum(byte *pData);

void SetDataFor_int(void *dest, void *src);
byte* MovePtrBySizeOf_int(byte *pData);
byte* CreateInstanceOf_int(void);
void DestroyInstanceOf_int(byte *pData);


#endif
