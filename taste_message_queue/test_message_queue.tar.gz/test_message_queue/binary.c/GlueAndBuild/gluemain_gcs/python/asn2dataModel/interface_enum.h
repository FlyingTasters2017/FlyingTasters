/* This file was generated automatically: DO NOT MODIFY IT ! */

/*
 *  Use the enum values at your convenience, if you need them to encode/decode
 *  messages for your driver with a header field that identifies the sender/receiver
*/

enum {
    i_main_gcs_PI_displayData = 0,
    i_main_gcs_RI_takeoff = 0,
    i_main_gcs_PI_gui_polling_main_gcs = 1
};
