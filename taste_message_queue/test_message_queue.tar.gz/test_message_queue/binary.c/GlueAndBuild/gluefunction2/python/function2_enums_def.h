/* This file was generated automatically: DO NOT MODIFY IT ! */

#ifndef _function2_ENUM_DEF_H
#define _function2_ENUM_DEF_H


typedef enum {
  i_TM_from_CF,
} T_function2_RI_list;

typedef enum {
  i_TC_from_TASTE,
} T_function2_PI_list;



#endif
