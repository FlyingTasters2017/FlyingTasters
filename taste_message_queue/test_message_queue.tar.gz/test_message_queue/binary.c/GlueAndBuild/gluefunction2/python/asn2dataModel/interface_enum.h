/* This file was generated automatically: DO NOT MODIFY IT ! */

/*
 *  Use the enum values at your convenience, if you need them to encode/decode
 *  messages for your driver with a header field that identifies the sender/receiver
*/

enum {
    i_function2_PI_TC_from_TASTE = 0,
    i_function2_RI_TM_from_CF = 0,
    i_function2_PI_gui_polling_function2 = 1
};
