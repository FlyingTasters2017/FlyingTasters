#!/usr/bin/python

import DV

FVname = "function2"

tc = {}
tm = {}
errCodes = {}

tm["TC_from_TASTE"] = {'nodeTypename': 'TC-T', 'type': 'SEQUENCE', 'id': 'TC_from_TASTE', "children":[{'nodeTypename': '', 'type': 'REAL', 'id': 'roll', 'minR': -360, 'maxR': 360},
{'nodeTypename': '', 'type': 'REAL', 'id': 'pitch', 'minR': -360, 'maxR': 360},
{'nodeTypename': '', 'type': 'REAL', 'id': 'yaw', 'minR': -100000, 'maxR': 100000},
{'nodeTypename': '', 'type': 'INTEGER', 'id': 'thrust', 'minR': 0, 'maxR': 65535}]}
tc["TM_from_CF"] = {'nodeTypename': 'TM-T', 'type': 'SEQUENCE', 'id': 'TM_from_CF', "children":[{'nodeTypename': '', 'type': 'SEQUENCE', 'id': 'gyro', "children":[{'nodeTypename': '', 'type': 'REAL', 'id': 'x', 'minR': -100000, 'maxR': 100000},
{'nodeTypename': '', 'type': 'REAL', 'id': 'y', 'minR': -100000, 'maxR': 100000},
{'nodeTypename': '', 'type': 'REAL', 'id': 'z', 'minR': -100000, 'maxR': 100000}]},
{'nodeTypename': '', 'type': 'SEQUENCE', 'id': 'acc', "children":[{'nodeTypename': '', 'type': 'REAL', 'id': 'x', 'minR': -16, 'maxR': 16},
{'nodeTypename': '', 'type': 'REAL', 'id': 'y', 'minR': -16, 'maxR': 16},
{'nodeTypename': '', 'type': 'REAL', 'id': 'z', 'minR': -16, 'maxR': 16}]},
{'nodeTypename': '', 'type': 'INTEGER', 'id': 'z', 'minR': 0, 'maxR': 8191}]}
