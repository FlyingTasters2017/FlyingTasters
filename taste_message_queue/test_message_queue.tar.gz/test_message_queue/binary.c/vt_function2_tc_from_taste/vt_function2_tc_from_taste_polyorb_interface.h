/* This file was generated automatically: DO NOT MODIFY IT ! */

#ifndef vt_function2_tc_from_taste_POLYORB_INTERFACE
#define vt_function2_tc_from_taste_POLYORB_INTERFACE
#include <stddef.h>

#include "types.h"
#include "deployment.h"
#include "po_hi_transport.h"
#include "../../function2/function2_polyorb_interface.h"
/*----------------------------------------------------
-- Asynchronous Provided Interface "artificial_TC_from_TASTE"
----------------------------------------------------*/
void po_hi_c_vt_function2_tc_from_taste_artificial_tc_from_taste(__po_hi_task_id, dataview__tc_t_buffer_impl);

/* ------------------------------------------------------
--  Synchronous Required Interface "TC_from_TASTE"
------------------------------------------------------ */
void vm_vt_function2_tc_from_taste_TC_from_TASTE(void *tc_data, size_t tc_data_len);
/* ------------------------------------------------------
--  Asynchronous Required Interface "TM_from_CF_vt"
------------------------------------------------------ */
void vm_async_vt_function2_tc_from_taste_TM_from_CF_vt(void *tm_data, size_t tm_data_len);
#endif
