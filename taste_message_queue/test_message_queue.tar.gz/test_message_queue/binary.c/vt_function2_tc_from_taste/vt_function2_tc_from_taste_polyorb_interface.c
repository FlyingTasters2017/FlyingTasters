#include "po_hi_gqueue.h"
/* This file was generated automatically: DO NOT MODIFY IT ! */

#include "vt_function2_tc_from_taste_polyorb_interface.h"

#include "activity.h"
#include "types.h"
#include "po_hi_task.h"
/* ------------------------------------------------------
-- Asynchronous Provided Interface "artificial_TC_from_TASTE"
------------------------------------------------------ */
void po_hi_c_vt_function2_tc_from_taste_artificial_tc_from_taste(__po_hi_task_id e, dataview__tc_t_buffer_impl buf)
{
	sync_function2_TC_from_TASTE (buf.buffer, buf.length);
}

/* ------------------------------------------------------
--  Synchronous Required Interface "TC_from_TASTE"
------------------------------------------------------ */
void vm_vt_function2_tc_from_taste_TC_from_TASTE(void *tc_data, size_t tc_data_len)
{
	sync_function2_TC_from_TASTE(tc_data, tc_data_len);
}

/* ------------------------------------------------------
--  Asynchronous Required Interface "TM_from_CF_vt"
------------------------------------------------------ */
void vm_async_vt_function2_tc_from_taste_TM_from_CF_vt(void *tm_data, size_t tm_data_len)
{
	__po_hi_request_t request;

	__po_hi_copy_array(&(request.vars.vt_function2_tc_from_taste_global_outport_tm_from_cf_vt.vt_function2_tc_from_taste_global_outport_tm_from_cf_vt.buffer), tm_data, tm_data_len);
	request.vars.vt_function2_tc_from_taste_global_outport_tm_from_cf_vt.vt_function2_tc_from_taste_global_outport_tm_from_cf_vt.length = tm_data_len;
	request.port = vt_function2_tc_from_taste_global_outport_tm_from_cf_vt;
	__po_hi_gqueue_store_out(x86_partition_vt_function2_tc_from_taste_k, vt_function2_tc_from_taste_local_outport_tm_from_cf_vt, &request);
	__po_hi_send_output(x86_partition_vt_function2_tc_from_taste_k, vt_function2_tc_from_taste_global_outport_tm_from_cf_vt);
}

