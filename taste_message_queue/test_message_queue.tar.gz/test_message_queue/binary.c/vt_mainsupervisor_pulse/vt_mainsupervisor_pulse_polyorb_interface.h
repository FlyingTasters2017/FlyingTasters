/* This file was generated automatically: DO NOT MODIFY IT ! */

#ifndef vt_mainsupervisor_pulse_POLYORB_INTERFACE
#define vt_mainsupervisor_pulse_POLYORB_INTERFACE
#include <stddef.h>

#include "types.h"
#include "deployment.h"
#include "po_hi_transport.h"
#include "../../mainsupervisor/mainsupervisor_polyorb_interface.h"
#include "../../function1/function1_polyorb_interface.h"
#include "../../x86_partition_taste_api/x86_partition_taste_api_polyorb_interface.h"
/*----------------------------------------------------
-- Asynchronous Provided Interface "artificial_pulse"
----------------------------------------------------*/
void po_hi_c_vt_mainsupervisor_pulse_artificial_pulse(__po_hi_task_id);

/* ------------------------------------------------------
--  Synchronous Required Interface "pulse"
------------------------------------------------------ */
void vm_vt_mainsupervisor_pulse_pulse();
/* ------------------------------------------------------
--  Asynchronous Required Interface "displayData_vt"
------------------------------------------------------ */
void vm_async_vt_mainsupervisor_pulse_displayData_vt(void *tm_data, size_t tm_data_len);
/* ------------------------------------------------------
--  Synchronous Required Interface "TC_from_TASTE_vt"
------------------------------------------------------ */
void vm_vt_mainsupervisor_pulse_TC_from_TASTE_vt(void *tc_data, size_t tc_data_len);
/* ------------------------------------------------------
--  Synchronous Required Interface "check_queue_vt"
------------------------------------------------------ */
void vm_vt_mainsupervisor_pulse_check_queue_vt(void *, size_t *);
#endif
