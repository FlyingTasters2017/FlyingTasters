#include "po_hi_gqueue.h"
/* This file was generated automatically: DO NOT MODIFY IT ! */

#include "vt_mainsupervisor_pulse_polyorb_interface.h"

#include "activity.h"
#include "types.h"
#include "po_hi_task.h"
/* ------------------------------------------------------
-- Asynchronous Provided Interface "artificial_pulse"
------------------------------------------------------ */
void po_hi_c_vt_mainsupervisor_pulse_artificial_pulse(__po_hi_task_id e)
{
	sync_mainsupervisor_pulse ();
}

/* ------------------------------------------------------
--  Synchronous Required Interface "pulse"
------------------------------------------------------ */
void vm_vt_mainsupervisor_pulse_pulse()
{
	sync_mainsupervisor_pulse();
}

/* ------------------------------------------------------
--  Asynchronous Required Interface "displayData_vt"
------------------------------------------------------ */
void vm_async_vt_mainsupervisor_pulse_displayData_vt(void *tm_data, size_t tm_data_len)
{
	__po_hi_request_t request;

	__po_hi_copy_array(&(request.vars.vt_mainsupervisor_pulse_global_outport_displaydata_vt.vt_mainsupervisor_pulse_global_outport_displaydata_vt.buffer), tm_data, tm_data_len);
	request.vars.vt_mainsupervisor_pulse_global_outport_displaydata_vt.vt_mainsupervisor_pulse_global_outport_displaydata_vt.length = tm_data_len;
	request.port = vt_mainsupervisor_pulse_global_outport_displaydata_vt;
	__po_hi_gqueue_store_out(x86_partition_vt_mainsupervisor_pulse_k, vt_mainsupervisor_pulse_local_outport_displaydata_vt, &request);
	__po_hi_send_output(x86_partition_vt_mainsupervisor_pulse_k, vt_mainsupervisor_pulse_global_outport_displaydata_vt);
}

/* ------------------------------------------------------
--  Synchronous Required Interface "TC_from_TASTE_vt"
------------------------------------------------------ */
void vm_vt_mainsupervisor_pulse_TC_from_TASTE_vt(void *tc_data, size_t tc_data_len)
{
	sync_function1_TC_from_TASTE(tc_data, tc_data_len);
}

/* ------------------------------------------------------
--  Synchronous Required Interface "check_queue_vt"
------------------------------------------------------ */
void vm_vt_mainsupervisor_pulse_check_queue_vt(void *res, size_t *res_len)
{
	sync_x86_partition_taste_api_mainsupervisor_has_pending_msg(res, res_len);
}

