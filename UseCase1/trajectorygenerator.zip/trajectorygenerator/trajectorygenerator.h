/* This file was generated automatically: DO NOT MODIFY IT ! */

/* Declaration of the functions that have to be provided by the user */

#ifndef __USER_CODE_H_trajectorygenerator__
#define __USER_CODE_H_trajectorygenerator__

#include "C_ASN1_Types.h"

#ifdef __cplusplus
extern "C" {
#endif

void trajectorygenerator_startup();

void trajectorygenerator_PI_GetTrajectory(const asn1SccMyInteger *,
                                          const asn1SccMyReal *,
                                          asn1SccMyReal *);

#ifdef __cplusplus
}
#endif


#endif
