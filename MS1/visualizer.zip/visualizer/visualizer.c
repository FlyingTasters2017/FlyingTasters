/* User code: This file will not be overwritten by TASTE. */

#include "visualizer.h"

void visualizer_startup()
{
    /* Write your initialization code here,
       but do not make any call to a required interface. */
}

void visualizer_PI_display()
{
    /* Write your code here! */
}

