/* User code: This file will not be overwritten by TASTE. */

#include "mission_safety.h"

void mission_safety_startup()
{
    /* Write your initialization code here,
       but do not make any call to a required interface. */
}

void mission_safety_PI_check_mission_safety(const asn1SccWorldData *IN_processed_world_data,
                                            asn1SccSafetyInterupt *OUT_world_safety_events)
{
    /* Write your code here! */
}

