/* User code: This file will not be overwritten by TASTE. */

#include "enable_pass.h"

void enable_pass_startup()
{
    /* Write your initialization code here,
       but do not make any call to a required interface. */
}

void enable_pass_PI_enable_pixycam(const asn1SccMyInteger *IN_user_input)
{
    /* Write your code here! */
}

