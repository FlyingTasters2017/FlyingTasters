/* User code: This file will not be overwritten by TASTE. */

#include "asd_storage.h"

void asd_storage_startup()
{
    /* Write your initialization code here,
       but do not make any call to a required interface. */
}

void asd_storage_PI_store_ASD()
{
    /* Write your code here! */
}

void asd_storage_PI_get_ASD_storage()
{
    /* Write your code here! */
}

