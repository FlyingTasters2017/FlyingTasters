/* This file was generated automatically: DO NOT MODIFY IT ! */

/* Declaration of the functions that have to be provided by the user */

#ifndef __USER_CODE_H_asd_storage__
#define __USER_CODE_H_asd_storage__

#include "C_ASN1_Types.h"

#ifdef __cplusplus
extern "C" {
#endif

void asd_storage_startup();

void asd_storage_PI_store_ASD(const asn1SccMyInteger *);

void asd_storage_PI_get_ASD_storage(const asn1SccMyInteger *);

#ifdef __cplusplus
}
#endif


#endif
