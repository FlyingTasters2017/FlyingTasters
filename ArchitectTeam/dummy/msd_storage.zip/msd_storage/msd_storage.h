/* This file was generated automatically: DO NOT MODIFY IT ! */

/* Declaration of the functions that have to be provided by the user */

#ifndef __USER_CODE_H_msd_storage__
#define __USER_CODE_H_msd_storage__

#include "C_ASN1_Types.h"
#include <stdio.h>


#ifdef __cplusplus
extern "C" {
#endif

void msd_storage_startup();

void msd_storage_PI_get_MSD_storage(asn1SccMyInteger *);

void msd_storage_PI_store_MSD(const asn1SccMyInteger *);

//asn1SccMyInteger internalData;


#ifdef __cplusplus
}
#endif


#endif
