/* This file was generated automatically: DO NOT MODIFY IT ! */

/* Declaration of the functions that have to be provided by the user */

#ifndef __USER_CODE_H_world_model__
#define __USER_CODE_H_world_model__

#include "C_ASN1_Types.h"

#ifdef __cplusplus
extern "C" {
#endif

void world_model_startup();

void world_model_PI_process_world_data(const asn1SccMyInteger *,
                                       asn1SccMyInteger *);

#ifdef __cplusplus
}
#endif


#endif
