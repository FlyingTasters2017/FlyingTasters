/* This file was generated automatically: DO NOT MODIFY IT ! */

/* Declaration of the functions that have to be provided by the user */

#ifndef __USER_CODE_H_control_low__
#define __USER_CODE_H_control_low__

#include "C_ASN1_Types.h"

#ifdef __cplusplus
extern "C" {
#endif

void control_low_startup();

void control_low_PI_Compute_Thrust(const asn1SccMyInteger *,
                                   asn1SccMyInteger *);

#ifdef __cplusplus
}
#endif


#endif
